#!/usr/bin/env bash
# =============================================================================
#  build-iso.sh -- Nexus OS 1 (v1.0 Stable) canli ISO uretici  [Arch Linux / archiso]
#
#  Cikti: out/NexusOS-1.0-x86_64.iso   (BIOS + UEFI hibrit, USB'ye dd ile yazilabilir)
#
#  Kullanim:
#    sudo ./build-iso.sh              Arch Linux uzerinde dogrudan (root gerekir)
#    sudo ./build-iso.sh --docker     Arch olmayan sistemlerde: archlinux konteynerinde derle (Docker/Podman)
#    ./build-iso.sh --stage-only      yalnizca archiso profilini hazirla, ISO uretme (inceleme)
#    ./build-iso.sh --clean           work/ ve out/ klasorlerini sil
#
#  Ortam: NEXUS_RELENG=/yol   (varsayilan /usr/share/archiso/configs/releng)
# =============================================================================
set -euo pipefail

NEXUS_VERSION="1.0"
ISO_NAME="NexusOS"
ISO_LABEL="NEXUS_1_0"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="$ROOT/work"
OUT="$ROOT/out"
PROFILE="$WORK/profile"
RELENG="${NEXUS_RELENG:-/usr/share/archiso/configs/releng}"

c_b=$'\e[1m'; c_g=$'\e[32m'; c_y=$'\e[33m'; c_r=$'\e[31m'; c_0=$'\e[0m'
say()  { printf '%s==>%s %s\n' "$c_g$c_b" "$c_0" "$*"; }
warn() { printf '%s==> UYARI:%s %s\n' "$c_y$c_b" "$c_0" "$*" >&2; }
die()  { printf '%s==> HATA:%s %s\n' "$c_r$c_b" "$c_0" "$*" >&2; exit 1; }

# ----------------------------------------------------------------------------- docker
run_in_docker() {
    local engine
    engine="$(command -v docker || command -v podman || true)"
    [[ -n "$engine" ]] || die "docker veya podman gerekli (--docker modu)"
    say "archlinux konteynerinde derleniyor ($engine) -- ilk calistirmada paket indirmesi birkac dakika surer"
    mkdir -p "$OUT"
    "$engine" run --rm --privileged \
        -v "$ROOT":/nexus -w /nexus \
        -e NEXUS_IN_CONTAINER=1 \
        archlinux:latest \
        bash -c 'set -e; pacman -Syu --noconfirm --needed archiso || pacman --disable-sandbox -Syu --noconfirm --needed archiso; bash ./build-iso.sh'
    exit $?
}

# ----------------------------------------------------------------------------- profil
copy_profile() {
    [[ -d "$RELENG" ]] || die "archiso 'releng' profili bulunamadi: $RELENG  (pacman -S archiso)"
    [[ -n "$WORK" && "$WORK" != "/" ]] || die "WORK bos"
    rm -rf "$WORK"
    mkdir -p "$PROFILE" "$OUT"
    cp -a "$RELENG"/. "$PROFILE"/
    say "releng profili kopyalandi: $RELENG"
}

add_packages() {
    local list="$PROFILE/packages.x86_64"
    [[ -f "$list" ]] || die "packages.x86_64 yok"
    # releng listesi + bizim paketler; yorumlari/bos satirlari at, tekrarlari kaldir
    cat "$list" "$ROOT/config/packages.add" | sed -e 's/#.*$//' -e 's/[[:space:]]*$//' | awk 'NF && !seen[$0]++' >"$list.new"
    mv "$list.new" "$list"
    say "paket listesi: $(wc -l <"$list") paket"
}

brand_profiledef() {
    local f="$PROFILE/profiledef.sh"
    [[ -f "$f" ]] || die "profiledef.sh yok"
    sed -i -E \
        -e "s|^iso_name=.*|iso_name=\"$ISO_NAME\"|" \
        -e "s|^iso_label=.*|iso_label=\"$ISO_LABEL\"|" \
        -e "s|^iso_publisher=.*|iso_publisher=\"Nexus OS Project\"|" \
        -e "s|^iso_application=.*|iso_application=\"Nexus OS 1 v$NEXUS_VERSION Live\"|" \
        -e "s|^iso_version=.*|iso_version=\"$NEXUS_VERSION\"|" \
        "$f"
    # dosya izinleri: arac betikleri, sudoers (0440 ZORUNLU), ev dizini
    cat >>"$f" <<'EOF'

# --- Nexus OS ---
file_permissions+=(
  ["/usr/bin/nexus-shell"]="0:0:755"
  ["/usr/bin/nexus-store.sh"]="0:0:755"
  ["/usr/lib/nexus-os/xsession"]="0:0:755"
  ["/etc/sudoers.d/10-nexus-store"]="0:0:440"
  ["/home/nexus"]="1000:1000:750"
)
EOF
    say "profiledef.sh markalandi (iso: $ISO_NAME-$NEXUS_VERSION-x86_64.iso)"
}

install_overlay() {
    local a="$PROFILE/airootfs"
    mkdir -p "$a"
    # 1) Nexus Shell (Python paketi) + baslatici + katalog
    install -d "$a/usr/lib/nexus-shell"
    cp -a "$ROOT/nexus-shell/nexus" "$a/usr/lib/nexus-shell/"
    find "$a/usr/lib/nexus-shell" -name '__pycache__' -type d -prune -exec rm -rf {} +
    install -Dm755 "$ROOT/nexus-shell/bin/nexus-shell" "$a/usr/bin/nexus-shell"
    install -Dm644 "$ROOT/nexus-shell/data/catalog.json" "$a/usr/share/nexus-os/catalog.json"
    install -Dm644 "$ROOT/README.md" "$a/usr/share/doc/nexus-os/README.md"
    # 2) sistem dosyalari: Store koprusu, systemd servisi, sudoers, Xorg, os-release...
    cp -a "$ROOT/system"/. "$a"/
    chmod 755 "$a/usr/bin/nexus-store.sh" "$a/usr/lib/nexus-os/xsession"
    chmod 440 "$a/etc/sudoers.d/10-nexus-store"
    # 3) oturum kullanicisi (releng kendi passwd/shadow/group dosyalarini getirir)
    install -d -m750 "$a/home/nexus"
    add_line "$a/etc/passwd"  '^nexus:'  'nexus:x:1000:1000:Nexus Session User:/home/nexus:/bin/bash'
    add_line "$a/etc/shadow"  '^nexus:'  'nexus:!*:19000:0:99999:7:::'
    add_line "$a/etc/group"   '^nexus:'  'nexus:x:1000:'
    add_line "$a/etc/gshadow" '^nexus:'  'nexus:!::'
    # 4) servisler: grafik hedef + kiosk kabuk + ag; releng'in tty1 otomatik girisi kaldirilir
    local sd="$a/etc/systemd/system"
    mkdir -p "$sd/graphical.target.wants" "$sd/multi-user.target.wants"
    ln -sf /usr/lib/systemd/system/graphical.target "$sd/default.target"
    ln -sf /usr/lib/systemd/system/nexus-shell.service "$sd/graphical.target.wants/nexus-shell.service"
    ln -sf /usr/lib/systemd/system/NetworkManager.service "$sd/multi-user.target.wants/NetworkManager.service"
    for u in systemd-networkd.service systemd-networkd.socket systemd-networkd-wait-online.service; do
        ln -sf /dev/null "$sd/$u"                                      # NetworkManager ile cakismasin
    done
    rm -rf "$sd/getty@tty1.service.d"
    say "Nexus Shell, Store koprusu, servisler ve 'nexus' kullanicisi profile islendi"
}

add_line() {            # dosya, desen, satir -> yoksa ekle (dosya yoksa olustur)
    local file="$1" pat="$2" line="$3"
    mkdir -p "$(dirname "$file")"
    touch "$file"
    grep -qE "$pat" "$file" || printf '%s\n' "$line" >>"$file"
}

brand_boot() {
    local files=() f
    for f in "$PROFILE"/syslinux/*.cfg "$PROFILE"/grub/*.cfg "$PROFILE"/efiboot/loader/entries/*.conf \
             "$PROFILE"/efiboot/loader/loader.conf; do
        [[ -f "$f" ]] && files+=("$f")
    done
    ((${#files[@]})) || warn "onyukleme yapilandirmasi bulunamadi; markalama atlandi"
    for f in "${files[@]}"; do
        sed -i \
            -e "s/Arch Linux install medium/Nexus OS 1 v$NEXUS_VERSION Live/g" \
            -e "s/Arch Linux/Nexus OS/g" \
            -e '/archisobasedir=/ s/$/ cow_spacesize=2G/' \
            "$f"
    done
    # syslinux (BIOS) menu gorseli
    if [[ -d "$PROFILE/syslinux" ]]; then
        install -Dm644 "$ROOT/branding/splash.png" "$PROFILE/syslinux/splash.png"
    fi
    if ! grep -rqs "Nexus OS" "$PROFILE/syslinux" "$PROFILE/grub" "$PROFILE/efiboot" 2>/dev/null; then
        warn "onyukleme menulerinde 'Nexus OS' etiketi gorunmuyor -- releng yapisi degismis olabilir"
    fi
    say "onyukleme menuleri (syslinux/GRUB/systemd-boot) 'Nexus OS 1 v$NEXUS_VERSION' olarak markalandi"
}

# ----------------------------------------------------------------------------- derleme
preflight_packages() {
    # mkarchiso 15 dk calistiktan sonra yanlis paket adiyla patlamasin: once adlari dogrula
    command -v pacman >/dev/null || { warn "pacman yok; paket adi on-kontrolu atlandi"; return 0; }
    local missing=() p
    while read -r p; do
        [[ -z "$p" ]] && continue
        pacman -Si "$p" >/dev/null 2>&1 || pacman -Sg "$p" >/dev/null 2>&1 || missing+=("$p")
    done < <(sed -e 's/#.*$//' -e 's/[[:space:]]*$//' "$ROOT/config/packages.add" | awk 'NF')
    if ((${#missing[@]})); then
        die "depolarda bulunamayan paket(ler): ${missing[*]}  -- 'pacman -Sy' calistirin ya da config/packages.add'i duzeltin"
    fi
    say "paket on-kontrolu: tum paket adlari depolarda mevcut"
}

build_iso() {
    command -v mkarchiso >/dev/null || die "mkarchiso yok: 'pacman -S archiso' kurun"
    say "mkarchiso calisiyor (10-20 dk surebilir; ilk seferde paketler indirilir)..."
    mkarchiso -v -w "$WORK/tmp" -o "$OUT" "$PROFILE"
    local iso="$OUT/$ISO_NAME-$NEXUS_VERSION-x86_64.iso"
    [[ -f "$iso" ]] || iso="$(ls -1t "$OUT"/*.iso 2>/dev/null | head -n1 || true)"
    [[ -f "$iso" ]] || die "ISO uretilemedi"
    (cd "$OUT" && sha256sum "$(basename "$iso")" >"$(basename "$iso").sha256")
    say "HAZIR: $iso  ($(du -h "$iso" | cut -f1))"
    cat <<EOF

  Sanal makinede dene (BIOS):
    qemu-system-x86_64 -m 4G -enable-kvm -cdrom "$iso" -boot d -vga virtio -display gtk
  UEFI (OVMF):
    qemu-system-x86_64 -m 4G -enable-kvm -cdrom "$iso" -boot d -vga virtio -display gtk \\
        -drive if=pflash,format=raw,readonly=on,file=/usr/share/edk2/x64/OVMF_CODE.4m.fd
  USB'ye yaz:   sudo dd if="$iso" of=/dev/sdX bs=4M status=progress oflag=sync
  VirtualBox:   Tur=Linux/Arch Linux (64-bit), >=4 GB RAM, 128 MB video bellek, EFI istege bagli
EOF
}

main() {
    case "${1:-}" in
        --docker)     run_in_docker ;;
        --clean)      rm -rf "$WORK" "$OUT"; say "temizlendi"; exit 0 ;;
        --stage-only) copy_profile; add_packages; brand_profiledef; install_overlay; brand_boot
                      say "profil hazir: $PROFILE  (ISO uretilmedi)"; exit 0 ;;
        -h|--help)    sed -n '2,16p' "$0" | sed 's/^# \{0,2\}//'; exit 0 ;;
        "")           ;;
        *)            die "bilinmeyen secenek: $1 (--help)" ;;
    esac
    [[ $EUID -eq 0 ]] || die "root gerekir:  sudo ./build-iso.sh   (ya da --docker)"
    [[ -f /etc/arch-release || -n "${NEXUS_IN_CONTAINER:-}" ]] || die "Arch Linux degilsiniz: --docker kullanin"
    preflight_packages
    copy_profile; add_packages; brand_profiledef; install_overlay; brand_boot
    build_iso
}
main "$@"
