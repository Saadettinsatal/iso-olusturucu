# Nexus OS 1 (v1.0 Stable)

Arch Linux tabanlı, **sıfırdan yazılmış 3D masaüstü kabuğu** (Nexus Shell) ile açılan canlı işletim sistemi.
GNOME/KDE/XFCE veya herhangi bir masaüstü ortamı **yoktur**; ekranı tek bir tam ekran OpenGL uygulaması çizer.

```
 ┌───────────────────────────── Nexus OS 1 ─────────────────────────────┐
 │  Nexus Shell (Python + OpenGL 3.3)   3D sahne · cam paneller · dock  │
 │    ├─ Nexus Store (3D kartlar) ──► nexus-store.sh install <paket>    │
 │    ├─ Sistem İzleyici · Sistem (güç/hakkında)                        │
 │  Xorg (xinit, kiosk)  ◄── systemd: nexus-shell.service (tty1)        │
 │  Arch Linux: linux · pacman · NetworkManager · PipeWire · Mesa       │
 │  Önyükleme: archiso (syslinux BIOS + systemd-boot UEFI, hibrit ISO)  │
 └───────────────────────────────────────────────────────────────────────┘
```

## 1. ISO üretimi (3 yol — hangisi sana uyuyorsa)

ISO ≈ 1.3–1.6 GB çıkar: `out/NexusOS-1.0-x86_64.iso` (+ `.sha256`), BIOS + UEFI hibrit.

**A) Bulutta, bilgisayarsız Arch/Docker olmadan (GitHub Actions)**
1. GitHub'da boş bir depo aç, bu klasörün içeriğini yükle. *Not:* `.github` gizli klasördür; web arayüzü atlarsa
   **Add file → Create new file**, adı `.github/workflows/build-iso.yml`, içeriği bu depodaki dosyadan yapıştır. (En kolayı `git push`.)
2. **Actions → Build Nexus OS ISO → Run workflow**. ~30–50 dk sürer.
3. Bittiğinde çalışmanın sayfasında **Artifacts → NexusOS-1.0-x86_64-iso** indir. (`v1.0` gibi bir etiket atarsan **Releases**'e de konur.)

**B) Herhangi bir Ubuntu/Debian makinede veya kiralık sunucuda (VPS ≥ 4 GB RAM, 20 GB disk)**
```bash
sudo apt update && sudo apt install -y docker.io unzip
unzip nexus-os-1.0-arch.zip && cd nexus-arch
sudo bash build-iso.sh --docker          # -> out/NexusOS-1.0-x86_64.iso
```

**C) Arch Linux üzerinde**
```bash
sudo pacman -S --needed archiso
sudo bash build-iso.sh
```

`bash build-iso.sh --stage-only` yalnızca archiso profilini `work/profile` altında hazırlar (inceleme/özelleştirme için).
Derlemeden önce `config/packages.add` içindeki her paket adı depolarda aranır; yazım hatası varsa 15 dk beklemeden hemen durur.

**Deneme:** `qemu-system-x86_64 -m 4G -enable-kvm -cdrom out/NexusOS-1.0-x86_64.iso -boot d -vga virtio -display gtk`
(UEFI için `-drive if=pflash,format=raw,readonly=on,file=/usr/share/edk2/x64/OVMF_CODE.4m.fd` ekleyin).
**VirtualBox:** Tür *Linux / Arch Linux (64-bit)*, ≥ 4 GB RAM, video belleği 128 MB. **USB:** `sudo dd if=… of=/dev/sdX bs=4M status=progress oflag=sync`.

> Canlı sistemde kök dosya sistemi RAM üzerindedir. Önyükleme menüsü `cow_spacesize=2G` verir: Store'dan
> büyük uygulama (Firefox, SuperTuxKart…) kurmak için **≥ 4 GB RAM** önerilir.

## 2. Depo yapısı

| Yol | Görev |
|---|---|
| `build-iso.sh` | archiso `releng` profilini Nexus ile donatır, `mkarchiso` ile ISO üretir |
| `config/packages.add` | ISO'ya eklenen paketler |
| `nexus-shell/nexus/` | **Kabuk kaynak kodu** (aşağıya bakın) |
| `nexus-shell/data/catalog.json` | Store kataloğu (uygulamalar, kategoriler, paket adları) |
| `system/` | Hedef sisteme birebir kopyalanan dosyalar: `nexus-store.sh`, systemd birimi, xsession, sudoers, os-release, issue/motd, Xorg klavye |
| `packaging/PKGBUILD`, `install.sh` | ISO dışında, kurulu bir Arch'a kurulum |
| `branding/splash.png`, `tools/make_splash.py` | BIOS önyükleme menüsü görseli |
| `nexus-shell/tools/preview.py` | GPU olmadan sahnenin PNG önizlemesi |
| `nexus-shell/tests/`, `tools/check.sh` | Test paketi |

### Kabuk modülleri (`nexus-shell/nexus/`)

| Modül | Görev |
|---|---|
| `mathx.py` | Saf Python 4×4 matris, kamera, **ışın–düzlem kesişimi** (3D tıklama/sürükleme) |
| `spring.py` | Yay fiziği (yarı-örtük Euler, alt adımlı, kararlı) |
| `raster.py`, `ui.py` | Pillow ile anti-aliasli arayüz çizimi; yay animasyonlu butonlar |
| `objects.py` | `Obj3D` (panel/kart/simge) ve `Window` (trafik ışıklı pencere) |
| `scene.py` | Kamera (fare parallax'ı), nesne ağacı, **3D seçim**, derinlik sıralaması |
| `gl.py` | OpenGL 3.3 core hattı: 3D arka plan, bulanıklık, cam/bevel/fresnel shader'ı, zemin gölgeleri |
| `apps/store.py` | Nexus Store: kategoriler, arama, 3D uygulama kartları, öne çıkan banner, detay kartı |
| `apps/system.py` | Sistem İzleyici (canlı CPU/RAM/disk/ağ) ve Sistem penceresi |
| `dock.py` | 3D dock (gauss büyütme, eğilme, parıltı, ipucu) ve üst çubuk |
| `bridge.py` | **Store ↔ pacman köprüsü** |
| `shell.py` | Pencere yönetimi, girdi, ana döngü, GL başlatma (donanım → yazılım yedekli) |

## 3. 3D arayüz nasıl çalışır

- **Dünya birimi = z=0 düzleminde 1 piksel.** Kamera fov 40°, bu düzlemde 1:1 netlik verir; yüzeyler yakınlaştıkça büyür.
- Her pencere/kart/simge bir **Pillow yüzeyi (doku) taşıyan 3D dörtgen**dir; yalnızca değişince yeniden çizilir ve GPU'ya yüklenir.
  3D hareket (yaylar, eğilme) içerikten bağımsız 60 FPS akar.
- **Tıklama = ışın izleme:** fare → ters (projeksiyon×görünüm) → dünya ışını → nesnenin yerel z=0 düzlemi → yüzey pikseli.
  Böylece eğik/dönük panelde de düğmeler doğru yerde çalışır (testlerde 500 rastgele dönük panelde hata ~1e-11).
- **Yaylar:** hover'da kart `z` ekseninde öne çıkar, fareye doğru yatar, parlar; pencereyi sürüklerken hızına göre eğilir;
  odaktaki pencere öne alınır, diğerleri geriye itilir; dock simgeleri gauss eğrisiyle büyür (macOS tarzı) ve zıplar.
- **Shader:** arka plan kameradan ışın izlenerek çizilir (neon zemin ızgarası, güneş, yüzen 3D küreler, yıldızlar);
  sahne ¼ çözünürlükte bulanıklaştırılıp "buzlu cam" arka plan olur; kartlarda SDF-bevel normali, speküler ve fresnel kenar ışığı,
  neon parıltı; zemine yumuşak 3D gölge düşer.
- Mesa **llvmpipe** (yazılımsal GL) algılanırsa sahne yarı çözünürlükte çizilir (`NEXUS_QUALITY=low` ile elle).

Geliştirme: `NEXUS_WINDOWED=1 python3 nexus-shell/bin/nexus-shell` (1440×860 pencere; çıkış `Ctrl+Alt+Q`).
`NEXUS_SIM=1` Store'u sahte kurulumla çalıştırır (pacman gerekmez). GPU'suz önizleme: `python3 nexus-shell/tools/preview.py out.png --hover-card`.

## 4. Nexus Store ve pacman köprüsü

**"Install" tıklanınca çalışan komut tam olarak şudur:**

```
nexus-store.sh install <paket_adı>        # kaldırma: nexus-store.sh remove <paket_adı>
```

`nexus-store.sh` (`/usr/bin`) pacman'ı çağırır: `pacman -S --noconfirm --needed --noprogressbar <paket>`.
Kabuk çıktıyı satır satır okur, `Packages (N)`, `downloading`, `(n/m) installing` satırlarından **monoton bir ilerleme** hesaplar
ve karttaki ilerleme çubuğuna yansıtır; bitince uygulama **dock'a otomatik eklenir** (`exec` alanı doluysa).

Güvenlik (betik root ile çalışır, bu yüzden sıkıdır):
- Kabuk `nexus` kullanıcısıyla çalışır; `/etc/sudoers.d/10-nexus-store` yalnızca `nexus-store.sh install|remove` ve `systemctl poweroff|reboot` için parolasız root verir.
- Paket adı katı regex'e uymalı **ve `catalog.json` içinde bulunmalı**; fazla argüman, `-` ile başlayan seçenek, `;`, `$()` reddedilir.
- Aynı anda tek işlem (`flock`). Çevrimiçi göstergesi root gerektirmeyen DNS kontrolüyle (`check-online`) yapılır; `pacman -Sy` yalnızca veritabanı hiç yoksa (canlı ISO'da ilk kurulum) bir kez çalışır.

> **Arch uyarısı:** `-Sy` ile kısmi güncelleme resmî olarak desteklenmez. Canlı ISO'da yeni paket, ISO'daki kütüphanelerden daha yeni
> bağımlılık isteyebilir. ISO'yu sık yeniden üretin ya da `NEXUS_STORE_UPGRADE=1` ile `pacman -Syu` yaptırın.

**Uygulama eklemek:** `nexus-shell/data/catalog.json` içine `{id, name, category, pkg, rating, size_mb, featured, glyph, exec, tagline, description}` ekleyin.
`pkg` Arch depolarındaki gerçek paket adı olmalıdır; `exec` boşsa "Open" gösterilmez. (Puanlar katalogdaki düzenlenebilir meta veridir.)

## 5. Açılışta otomatik tam ekran (kiosk) — Arch + Xorg + systemd

ISO bunu zaten yapar. Kurulu bir Arch'ta elle:

```bash
sudo pacman -S --needed python python-pygame python-pyopengl python-pillow python-numpy \
     xorg-server xorg-xinit xorg-xset xorg-xsetroot xf86-input-libinput mesa ttf-dejavu noto-fonts xterm sudo
sudo ./install.sh                       # dosyaları kurar, 'nexus' kullanıcısını oluşturur, servisi etkinleştirir
sudo systemctl set-default graphical.target
sudo reboot
```

`install.sh` yerine paket de kurabilirsiniz: `cd packaging && makepkg -si`.

Mekanizma (`/usr/lib/systemd/system/nexus-shell.service`):
1. `User=nexus` + `PAMName=login` + `TTYPath=/dev/tty1` → logind oturumu açılır; Xorg **root'suz** çalışır.
2. `Conflicts=getty@tty1.service` → tty1'i grafik oturum devralır.
3. `ExecStart=/usr/bin/xinit /usr/lib/nexus-os/xsession -- :0 vt1 -keeptty -nolisten tcp` → `xsession` ekran koruyucuyu kapatıp `nexus-shell`'i başlatır.
4. `Restart=always` → kabuk çökerse 2 sn sonra yeniden başlar; 60 sn'de 5 başarısızlıktan sonra durur (**Ctrl+Alt+F2** → konsol).

Alternatif (servissiz): `getty@tty1` otomatik girişi + `~/.bash_profile` içinde `[ -z "$DISPLAY" ] && [ "$XDG_VTNR" = 1 ] && exec startx /usr/lib/nexus-os/xsession`.
**Wayland:** kabuk SDL/pygame üzerinden X11'e (`SDL_VIDEODRIVER=x11`) bağlanır; Wayland oturumunda XWayland ile de çalışır, ancak kiosk akışı Xorg içindir.

## 6. Test ve doğrulama

```bash
tools/check.sh          # tüm testler: matematik/ray-pick, köprü+betik güvenliği, uçtan uca kabuk, build-iso aşamalama
```
`tests/test_math.py` (numpy ile çapraz kontrol), `test_bridge.py` (sahte pacman ile gerçek `nexus-store.sh`; çalışan argv birebir `install <paket>`),
`test_shell.py` (başsız: 3D seçimle karta tıklayıp kurulum, sürükleme, dock büyütme, pencere yönetimi).

**Bu depoda doğrulanan / doğrulanamayan:**
- ✔ 3D matematik, seçim, yaylar, Store köprüsü ve betik güvenliği, kabuk mantığı, UI rasterlaştırma (PNG ile görsel kontrol), archiso profil hazırlama.
- ✘ **Gerçek GPU/OpenGL çizimi (`gl.py`) ve `mkarchiso` ile ISO'nun fiilen derlenip önyüklenmesi** geliştirme ortamında (GPU, Arch, QEMU yok) çalıştırılamadı.
  İlk denemede shader/paket adı hatası çıkarsa çıktıyı (`journalctl -u nexus-shell`, `build-iso.sh` günlüğü) iletin.

## 7. Bilinen sınırlar (v1.0)

- Store'dan kurulan uygulamalar kabuğun **içinde değil**, ayrı X penceresi olarak (pencere yöneticisi yok, kenarlıksız) açılır; kabuk arkada kalır.
  Yol haritası: kabuğun kendi kompozitörü (Wayland/wlroots) ile dış uygulamaları da 3D panellere almak.
- Canlı sistem kalıcı değildir (RAM); kurulum sihirbazı yok (`archinstall` konsoldan kullanılabilir).
- Pencere büyütme ölçekle yapılır (en çok ×1.3); içerik biraz yumuşar.
- Wi-Fi arayüzü yok: `nmtui`/`nmcli` için Terminal simgesini (xterm) kullanın.

## 8. Sorun giderme

| Belirti | Çözüm |
|---|---|
| Siyah ekran, servis yeniden başlıyor | `journalctl -u nexus-shell -b`; `NEXUS_SOFTWARE_GL=1` ile yazılım GL deneyin (`Environment=` satırı) |
| Çok yavaş (sanal makine) | VM'de 3D hızlandırmayı açın ya da `NEXUS_QUALITY=low` |
| Store "Offline" | NetworkManager: Terminal → `nmtui` |
| Kurulum "not in the Nexus catalog" | Paketi `catalog.json`'a ekleyin |
| Kurulum "unable to satisfy dependency" | Kısmi güncelleme: ISO'yu yeniden üretin ya da `NEXUS_STORE_UPGRADE=1` |
