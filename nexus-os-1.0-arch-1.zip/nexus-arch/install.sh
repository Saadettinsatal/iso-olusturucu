#!/usr/bin/env bash
# install.sh -- Nexus Shell'i KURULU bir Arch Linux'a kurar (ISO disinda).  sudo ./install.sh [DESTDIR]
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
D="${1:-${DESTDIR:-}}"
[[ -n "$D" || $EUID -eq 0 ]] || { echo "root gerekir: sudo ./install.sh" >&2; exit 1; }

install -d "$D/usr/lib/nexus-shell" "$D/usr/share/doc/nexus-os"
cp -a "$ROOT/nexus-shell/nexus" "$D/usr/lib/nexus-shell/"
find "$D/usr/lib/nexus-shell" -name '__pycache__' -type d -prune -exec rm -rf {} +
install -Dm755 "$ROOT/nexus-shell/bin/nexus-shell"        "$D/usr/bin/nexus-shell"
install -Dm644 "$ROOT/nexus-shell/data/catalog.json"      "$D/usr/share/nexus-os/catalog.json"
install -Dm644 "$ROOT/README.md"                          "$D/usr/share/doc/nexus-os/README.md"
install -Dm755 "$ROOT/system/usr/bin/nexus-store.sh"      "$D/usr/bin/nexus-store.sh"
install -Dm755 "$ROOT/system/usr/lib/nexus-os/xsession"   "$D/usr/lib/nexus-os/xsession"
install -Dm644 "$ROOT/system/usr/lib/systemd/system/nexus-shell.service" "$D/usr/lib/systemd/system/nexus-shell.service"
install -Dm644 "$ROOT/system/usr/lib/sysusers.d/nexus-os.conf" "$D/usr/lib/sysusers.d/nexus-os.conf"
install -Dm644 "$ROOT/system/usr/lib/tmpfiles.d/nexus-os.conf" "$D/usr/lib/tmpfiles.d/nexus-os.conf"
install -Dm440 "$ROOT/system/etc/sudoers.d/10-nexus-store" "$D/etc/sudoers.d/10-nexus-store"
install -Dm644 "$ROOT/system/etc/X11/xorg.conf.d/00-nexus-keyboard.conf" "$D/etc/X11/xorg.conf.d/00-nexus-keyboard.conf"
install -Dm644 "$ROOT/system/etc/nexus-release" "$D/etc/nexus-release"

if [[ -z "$D" ]]; then                       # yalnizca gercek sistemde
    systemd-sysusers nexus-os.conf
    systemd-tmpfiles --create nexus-os.conf
    install -Dm644 "$ROOT/system/etc/os-release" /etc/os-release
    install -Dm644 "$ROOT/system/etc/issue" /etc/issue
    install -Dm644 "$ROOT/system/etc/motd"  /etc/motd
    systemctl daemon-reload
    systemctl enable nexus-shell.service
    echo "Tamam. 'sudo systemctl set-default graphical.target' ve yeniden baslatin."
fi
