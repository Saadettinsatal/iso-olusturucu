#!/usr/bin/env bash
# build-iso.sh --stage-only'yi sahte bir releng profiliyle dogrular (Arch/archiso gerekmez).
set -euo pipefail
cd "$(dirname "$0")/.."
F=$(mktemp -d)
mkdir -p "$F"/{syslinux,grub,efiboot/loader/entries,airootfs/etc/systemd/system/getty@tty1.service.d}
printf '#!/usr/bin/env bash\niso_name="archlinux"\niso_label="ARCH"\niso_publisher="x"\niso_application="x"\niso_version="1"\nfile_permissions=(\n  ["/etc/shadow"]="0:0:400"\n)\n' >"$F/profiledef.sh"
printf 'base\nlinux\nsudo\n' >"$F/packages.x86_64"
printf 'MENU LABEL Arch Linux install medium (x86_64, BIOS)\nAPPEND archisobasedir=%%INSTALL_DIR%% archisosearchuuid=%%ARCHISO_UUID%%\n' >"$F/syslinux/archiso-sys-linux.cfg"
printf 'menuentry "Arch Linux install medium (x86_64, UEFI)" {\n  linux /v archisobasedir=%%INSTALL_DIR%%\n}\n' >"$F/grub/grub.cfg"
printf 'title Arch Linux install medium\noptions archisobasedir=%%INSTALL_DIR%%\n' >"$F/efiboot/loader/entries/a.conf"
printf 'x\n' >"$F/airootfs/etc/systemd/system/getty@tty1.service.d/autologin.conf"
printf 'root:x:0:0::/root:/bin/zsh\n' >"$F/airootfs/etc/passwd"
NEXUS_RELENG="$F" bash ./build-iso.sh --stage-only >/dev/null
P=work/profile; ok=0; bad() { echo "  FAIL $1"; ok=1; }; good() { echo "  ok   $1"; }
grep -q 'iso_name="NexusOS"' $P/profiledef.sh && good "iso_name=NexusOS" || bad iso_name
grep -q 'Nexus OS 1 v1.0 Live' $P/syslinux/archiso-sys-linux.cfg $P/grub/grub.cfg $P/efiboot/loader/entries/a.conf && good "3 onyukleyicide Nexus OS 1 v1.0 etiketi" || bad boot_label
! grep -rq 'Arch Linux' $P/syslinux $P/grub $P/efiboot && good "'Arch Linux' etiketi kalmadi" || bad arch_label
[ "$(grep -c cow_spacesize=2G $P/syslinux/archiso-sys-linux.cfg $P/grub/grub.cfg $P/efiboot/loader/entries/a.conf | grep -c ':1')" = 3 ] && good "cow_spacesize=2G her onyukleyicide" || bad cow
grep -q '^nexus:x:1000' $P/airootfs/etc/passwd && grep -q '^root:' $P/airootfs/etc/passwd && good "nexus kullanicisi eklendi, root korundu" || bad user
[ ! -e $P/airootfs/etc/systemd/system/getty@tty1.service.d ] && good "tty1 otomatik girisi kaldirildi" || bad autologin
[ "$(readlink $P/airootfs/etc/systemd/system/default.target)" = /usr/lib/systemd/system/graphical.target ] && good "varsayilan hedef graphical" || bad target
[ -L $P/airootfs/etc/systemd/system/graphical.target.wants/nexus-shell.service ] && good "nexus-shell.service etkin" || bad service
[ "$(stat -c %a $P/airootfs/etc/sudoers.d/10-nexus-store)" = 440 ] && good "sudoers 0440" || bad sudoers
grep -q '"/etc/sudoers.d/10-nexus-store"\]="0:0:440"' $P/profiledef.sh && good "profiledef file_permissions sudoers 440" || bad perms
rm -rf work "$F"; exit $ok
