#!/usr/bin/env python3
"""make_splash.py -- onyukleme menusu icin Nexus splash gorseli (640x480 PNG, syslinux uyumlu)."""
import math, os, random, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 640, 480
out = sys.argv[1] if len(sys.argv) > 1 else "splash.png"
random.seed(7)
img = Image.new("RGB", (W, H))
d = ImageDraw.Draw(img)
for y in range(H):                                   # lacivert -> mor ufuk
    t = y / H
    k = max(0.0, 1.0 - t * 1.25) ** 2.2
    d.line([(0, y), (W, y)], fill=(int(15 + 52 * k), int(23 + 10 * k), int(42 + 56 * k)))
for _ in range(90):                                  # yildizlar
    x, y = random.randrange(W), random.randrange(int(H * 0.5))
    b = random.randrange(90, 220)
    d.point((x, y), fill=(b, b, min(255, b + 30)))
hz = int(H * 0.60)                                   # ufuk cizgisi
glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
g = ImageDraw.Draw(glow)
g.ellipse((W / 2 - 120, hz - 110, W / 2 + 120, hz + 110), fill=(168, 85, 247, 150))
g.ellipse((W / 2 - 60, hz - 60, W / 2 + 60, hz + 60), fill=(244, 114, 182, 210))
img = Image.alpha_composite(img.convert("RGBA"), glow.filter(ImageFilter.GaussianBlur(26)))
d = ImageDraw.Draw(img)
d.rectangle((0, hz, W, H), fill=(8, 13, 30, 255))    # zemin
for i in range(-14, 15):                             # perspektif izgara
    d.line([(W / 2 + i * 14, hz), (W / 2 + i * 120, H)], fill=(56, 140, 220, 170), width=1)
for k in range(1, 12):
    y = hz + (H - hz) * (k / 12) ** 2
    d.line([(0, y), (W, y)], fill=(168, 85, 247, 150), width=1)
d.rectangle((0, hz - 1, W, hz + 1), fill=(56, 189, 248, 200))
def font(sz, bold=True):
    for p in ("/usr/share/fonts/TTF/DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/usr/share/fonts/noto/NotoSans-Bold.ttf"):
        if os.path.exists(p):
            return ImageFont.truetype(p, sz)
    return ImageFont.load_default()
txt = Image.new("RGBA", (W, H), (0, 0, 0, 0))
t = ImageDraw.Draw(txt)
t.text((W / 2, 70), "NEXUS OS", font=font(58), fill=(226, 232, 240, 255), anchor="mm")
t.text((W / 2, 118), "1", font=font(30), fill=(56, 189, 248, 255), anchor="mm")
t.text((W / 2, 150), "v1.0  Stable", font=font(16), fill=(148, 163, 184, 255), anchor="mm")
neon = txt.filter(ImageFilter.GaussianBlur(7))
img = Image.alpha_composite(img, neon)
img = Image.alpha_composite(img, txt)
img.convert("RGB").save(out)
print("yazildi:", out)
