#!/usr/bin/env bash
# check.sh -- tum yerel testler. GPU/Arch/QEMU gerektirmez.
set -u
cd "$(dirname "$0")/.."
# GitHub web yuklemesi/zip bazen calistirma bitlerini dusurur: geri ver
chmod +x build-iso.sh install.sh tools/*.sh system/usr/bin/nexus-store.sh system/usr/lib/nexus-os/xsession nexus-shell/bin/nexus-shell 2>/dev/null || true
fail=0
run() { printf '\n\033[1m### %s\033[0m\n' "$1"; shift; "$@" || fail=1; }
run "betik sozdizimi"      bash -c 'for f in build-iso.sh install.sh system/usr/bin/nexus-store.sh tools/check.sh; do bash -n "$f" && echo "  ok $f"; done; sh -n system/usr/lib/nexus-os/xsession && echo "  ok xsession"'
run "python sozdizimi"     python3 -m compileall -q nexus-shell/nexus nexus-shell/bin && echo "  ok"
run "3D matematik + yay"   python3 nexus-shell/tests/test_math.py
run "Store koprusu"        python3 nexus-shell/tests/test_bridge.py
run "kabuk (basliksiz)"    python3 nexus-shell/tests/test_shell.py
run "GL hatti (sahte GL)"  python3 nexus-shell/tests/test_gl_pipeline.py
run "build-iso (aşamalama)" bash -c 'bash tools/stage_test.sh'
run "install.sh (DESTDIR)" bash -c 'd=$(mktemp -d) && bash ./install.sh "$d" && test -x "$d/usr/bin/nexus-store.sh" && test -f "$d/usr/lib/nexus-shell/nexus/shell.py" && test "$(stat -c %a "$d/etc/sudoers.d/10-nexus-store")" = 440 && echo "  ok: kurulum agaci ve izinler"'
echo; [ $fail -eq 0 ] && echo "TUM KONTROLLER GECTI" || { echo "BASARISIZ"; exit 1; }
