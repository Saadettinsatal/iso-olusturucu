import os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["NEXUS_SIM"] = "1"
from nexus import mathx as M, catalog
from nexus.shell import Shell
from nexus.bridge import StoreBridge, OK
from nexus.apps.store import StoreWindow, app_state
from nexus.dock import DockIcon, BASE_SC

fails = 0
def check(c, m):
    global fails; print(("  ok   " if c else "  FAIL ") + m); fails += 0 if c else 1

W, H = 1920, 1080
sh = Shell(W, H, gfx=None, bridge=StoreBridge(sim=True))
def step(sec, dt=1/60):
    for _ in range(int(sec / dt)): sh.update(dt)
def screen_of(obj, px, py):
    lx, ly = px - obj.w / 2, obj.h / 2 - py
    return M.project(sh.scene.vp, M.transform(obj._model, (lx, ly, 0))[:3], W, H)[:2]
def mouse_to(obj, px, py):
    x, y = screen_of(obj, px, py); sh.on_mouse_move(x, y); return x, y
def click(obj, px, py):
    x, y = mouse_to(obj, px, py); sh.on_mouse_down(x, y); sh.on_mouse_up(x, y)

step(2.5)
store = sh.windows["store"]
print("== acilis ==")
check(isinstance(store, StoreWindow) and sh.focused is store, "Nexus Store acildi ve odakta")
check(store.pos.at_rest(0.05) and abs(store.alpha.x - 1) < 0.01, "acilis animasyonu yayla yerine oturdu")
vis = [c for c in store.cards if c.visible]
check(store.banner.visible and len(vis) == 3, "Discover: one cikan banner + 3 uygulama karti (3D nesneler)")
check(len(sh.dock.icons) == 4, "dock: 4 sabit simge")

print("== 3D secim: kart uzerine gel ==")
card = vis[0]
mouse_to(card, card.w / 2, 70); step(0.6)
check(sh.hover is card, "isin-kesisimi ile fare altindaki 3D kart bulundu (%s)" % card.app.name)
check(card.sc.x > 1.04 and card.pos.z > card.base[2] + 30, "hover: kart one cikti (olcek %.2f, z +%.0f)" % (card.sc.x, card.pos.z - card.base[2]))
check(abs(card.tilt.x) + abs(card.tilt.y) > 1e-3, "hover: kart fareye dogru yatti")
check(card.glow.x > 0.5, "hover: neon parilti")

print("== Install tiklama -> nexus-store.sh akisi ==")
app = card.app
bx, by = 16 + 100, card.h - 50 + 17                     # Install butonunun ortasi
click(card, bx, by)
step(0.2)
j = sh.bridge.job(app.pkg)
check(j is not None and j.op == "install", "tiklama %s icin kurulum isini baslatti" % app.pkg)
prog = []
t0 = time.time()
while j.state != OK and time.time() - t0 < 10:      # is parcacigi gercek zamanli calisir
    step(1/60); prog.append(j.progress); time.sleep(0.016)
check(max(prog) > 0.5 and card._sig is not None, "ilerleme akisi karta yansidi")
step(0.5)
check(sh.bridge.is_installed(app.pkg) and app_state(sh.bridge, app)[0] == "installed", "kurulum bitti -> kart 'installed' durumunda")
check(any(i.key == "app:" + app.id for i in sh.dock.icons) if app.exec else True, "kurulan uygulama dock'a otomatik eklendi")
# ikinci tiklama: Uninstall/Open
mouse_to(card, 16 + 150, by); step(0.3)
click(card, 16 + 150, by)       # sag taraf = Uninstall (Open | Uninstall)
t0 = time.time()
while (sh.bridge.busy or sh.bridge.job(app.pkg).op != "remove") and time.time() - t0 < 10: step(1/60); time.sleep(0.016)
step(0.5)
check(not sh.bridge.is_installed(app.pkg), "Uninstall ile kaldirildi")

print("== detay karti ==")
step(0.5); mouse_to(card, card.w / 2, 100); step(0.2)
click(card, card.w / 2, 100); step(1.2)
check(store.detail.visible and store.detail.app is card.app, "kart govdesine tiklayinca 3D detay karti acildi")
check(all(k.no_pick for k in store.cards if k.visible), "detay acikken arkadaki kartlar tiklanamaz")
click(store.detail, store.detail.w - 38, 38); step(1.0)
check(not store.detail.visible, "detay karti kapatildi")

print("== kategori + arama ==")
click(store, 100, 76 + 2 * 46 + 19)   # Games (panel yuzey koordinati)
step(1.5)
check(store.cat == 2 and not store.banner.visible and all(c.app.category == "Games" for c in store.cards if c.visible),
      "Games kategorisi: sadece oyunlar, banner yok (%d kart)" % len([c for c in store.cards if c.visible]))
store.on_key("v")
check(store.search_focus is False, "arama odakta degilken tus yoksayildi")
click(store, store.w - 28 - 135, 81); step(0.3)
for ch in "kart": store.on_key(ch)
step(1.0)
check(store.search_focus and store.query == "kart" and [c.app.id for c in store.cards if c.visible] == ["supertuxkart"],
      "arama: 'kart' -> SuperTuxKart")
store.on_key("ESC")
store.cat = 0; store.layout(); step(1.0)
click(store, 100, 76 + 19); step(0.5)

print("== pencere surukleme (3D duzlemde) ==")
tb = (store.w / 2 + 200, 20)
x0, y0 = mouse_to(store, *tb); sh.on_mouse_down(x0, y0)
before = (store.pos.a[0].t, store.pos.a[1].t)
for k in range(1, 25): sh.on_mouse_move(x0 + k * 10, y0 - k * 4); step(1/60)
after = (store.pos.a[0].t, store.pos.a[1].t)
check(sh.drag is not None and abs(after[0] - before[0]) > 150 and after[1] - before[1] > 60, "basliktan surukleme: panel fareyi izledi (dx=%.0f dy=%.0f)" % (after[0]-before[0], after[1]-before[1]))
step(0.15)
check(abs(store.rot.a[1].t) > 0.01 or abs(store.rot.y) > 0.005, "surukleme hizina gore egilme (rotY=%.3f)" % store.rot.y)
sh.on_mouse_up(x0 + 240, y0 - 96); step(2.0)
check(sh.drag is None and abs(store.rot.y) < 0.01, "birakinca yay ile duzeldi")

print("== dock buyutme ==")
ic = sh.dock.icons[1]; sx, sy = M.project(sh.scene.vp, M.transform(ic._model, (0, 0, 0))[:3], W, H)[:2]
sh.on_mouse_move(sx, sy); step(1.2)
check(ic.sc.x > BASE_SC + 0.4, "fare ustunde simge buyudu (%.2f -> %.2f)" % (BASE_SC, ic.sc.x))
nb = sh.dock.icons[0]; check(nb.sc.x > BASE_SC + 0.05 and nb.sc.x < ic.sc.x, "komsu simge kismen buyudu (gauss egrisi)")
check(ic.glow.x > 0.5 and sh.dock.tip.alpha.t == 1.0 and sh.dock.tip.text == ic.label, "parilti + ipucu: %r" % sh.dock.tip.text)
sh.on_mouse_move(W / 2, 200); step(1.5)
check(abs(ic.sc.x - BASE_SC) < 0.02, "fare ayrilinca yay ile dinlenme olcegine dondu")

print("== pencere yonetimi ==")
sx, sy = M.project(sh.scene.vp, M.transform(sh.dock.icons[1]._model, (0, 0, 0))[:3], W, H)[:2]
sh.on_mouse_move(sx, sy); sh.on_mouse_down(sx, sy); sh.on_mouse_up(sx, sy); step(1.5)
check("monitor" in sh.windows and sh.focused is sh.windows["monitor"], "dock simgesi tiklaninca Sistem Izleyici acildi + odaklandi")
mon = sh.windows["monitor"]; check(mon.pos.z > store.pos.z + 50, "odaktaki panel one cekildi, digeri geriye itildi (z %.0f vs %.0f)" % (mon.pos.z, store.pos.z))
click(mon, 26, 24); step(1.0)
check("monitor" not in sh.windows, "kirmizi nokta: pencere kapandi ve sahneden kalkti")
click(store, 48, 24); step(1.5)
check(store.minimized and not store.visible, "sari nokta: dock'a kuculdu")
sh.toggle_window("store"); step(1.5)
check(not store.minimized and store.visible and store.alpha.x > 0.95, "dock'tan geri getirildi")
print("\nBASARISIZ (%d)" % fails if fails else "\nTUM TESTLER GECTI"); sys.exit(1 if fails else 0)
