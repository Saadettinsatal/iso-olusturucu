import math, random, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np
from nexus import mathx as M
from nexus.spring import Spring, Spring3, BOUNCY

fails = 0
def check(c, m):
    global fails
    print(("  ok   " if c else "  FAIL ") + m)
    fails += 0 if c else 1

def close(a, b, e=1e-6): return all(abs(x - y) < e for x, y in zip(a, b))

print("== matris cebiri ==")
random.seed(1)
m = M.mul_all(M.translate(3, -2, 5), M.rot_y(0.7), M.rot_x(-0.3), M.scale(2, 1.5, 1))
check(np.allclose(np.array(M.inverse(m)).reshape(4, 4), np.linalg.inv(np.array(m).reshape(4, 4)), atol=1e-9), "inverse == numpy.linalg.inv")
check(close(M.mul(m, M.inverse(m)), M.ident(), 1e-9), "M * M^-1 = I")
p = M.perspective(40, 16/9, 10, 10000)
check(np.allclose(np.array(M.inverse(p)).reshape(4, 4), np.linalg.inv(np.array(p).reshape(4, 4)), atol=1e-9), "perspective inverse")
check(close(M.transform(M.rot_z(math.pi/2), (1, 0, 0))[:3], (0, 1, 0)), "rot_z(90) x->y")
check(close(M.transform(M.rot_y(math.pi/2), (0, 0, 1))[:3], (1, 0, 0)), "rot_y(90) z->x")

print("== kamera: dunya birimi = piksel ==")
W, H, FOV = 1920, 1080, 40.0
cz = (H/2) / math.tan(math.radians(FOV)/2)
cam = (0.0, 0.0, cz)
vp = M.mul(M.perspective(FOV, W/H, 10, 10000), M.look_at(cam, (0, 0, 0)))
s0 = M.project(vp, (0, 0, 0), W, H); s1 = M.project(vp, (100, 0, 0), W, H); s2 = M.project(vp, (0, 100, 0), W, H)
check(close(s0[:2], (W/2, H/2), 1e-6), "orijin ekran merkezine duser")
check(abs((s1[0] - s0[0]) - 100) < 1e-6, "z=0'da 100 dunya birimi = 100 piksel (x)")
check(abs((s0[1] - s2[1]) - 100) < 1e-6, "z=0'da 100 dunya birimi = 100 piksel (y)")
s3 = M.project(vp, (100, 0, 200), W, H)
check((s3[0] - s0[0]) > 100, "kameraya yakin nesne buyuk gorunur (perspektif)")

print("== isin (ray) secimi: ileri izdusum -> geri secim ==")
inv_vp = M.inverse(vp)
errs = []
for _ in range(500):
    # rastgele donuk/olcekli/oteli bir panel; yerel bir noktayi ekrana izdus et, sonra isinla geri bul
    model = M.mul_all(M.translate(random.uniform(-600, 600), random.uniform(-300, 300), random.uniform(-200, 200)),
                      M.rot_y(random.uniform(-0.5, 0.5)), M.rot_x(random.uniform(-0.4, 0.4)),
                      M.rot_z(random.uniform(-0.2, 0.2)), M.scale(random.uniform(0.6, 1.6)))
    lx, ly = random.uniform(-400, 400), random.uniform(-250, 250)
    sp = M.project(M.mul(vp, model), (lx, ly, 0), W, H)
    o, d = M.unproject_ray(inv_vp, cam, sp[0], sp[1], W, H)
    lo, ld = M.ray_to_local(M.inverse(model), o, d)
    hit = M.ray_plane_z0(lo, ld)
    errs.append(max(abs(hit[1] - lx), abs(hit[2] - ly)))
check(max(errs) < 1e-6, "500 rastgele (donuk+olcekli) panelde pick hatasi < 1e-6 (max %.2e)" % max(errs))
# t parametresi: iki panel -> yakin olan kucuk t
near = M.translate(0, 0, 100); far = M.translate(0, 0, -100)
o, d = M.unproject_ray(inv_vp, cam, W/2, H/2, W, H)
tn = M.ray_plane_z0(*M.ray_to_local(M.inverse(near), o, d))[0]
tf = M.ray_plane_z0(*M.ray_to_local(M.inverse(far), o, d))[0]
check(tn < tf, "yakin panelin t'si daha kucuk (on siralama dogru)")
hw, t = M.ray_plane_world(o, d, 0.0)
check(close(hw, (0, 0, 0), 1e-6), "z=0 duzlemi kesisimi (surukleme icin)")

print("== yay fizigi ==")
s = Spring(0, **BOUNCY); s.t = 1.0
peak = 0
for _ in range(600):
    s.step(1/60); peak = max(peak, s.x)
check(abs(s.x - 1) < 1e-3 and s.at_rest(), "yay hedefe oturuyor")
check(peak > 1.02, "BOUNCY yay tasiyor (tepe %.3f) -> 'yay' hissi" % peak)
s = Spring(0, k=300, c=10); s.t = 1.0
for _ in range(10): s.step(0.5)   # cok buyuk dt
check(abs(s.x - 1) < 0.2 and abs(s.x) < 5, "buyuk dt'de patlamiyor (kararli)")
v = Spring3(0, 0, 0); v.to(10, -5, 3)
for _ in range(400): v.step(1/60)
check(close((v.x, v.y, v.z), (10, -5, 3), 1e-2), "Spring3 hedefe varir")
print("\nBASARISIZ (%d)" % fails if fails else "\nTUM TESTLER GECTI")
sys.exit(1 if fails else 0)
