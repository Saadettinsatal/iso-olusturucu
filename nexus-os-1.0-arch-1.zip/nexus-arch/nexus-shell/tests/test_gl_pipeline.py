"""gl.py'yi SAHTE bir OpenGL ile calistirir: GPU olmadan Python tarafi hatalarini yakalar.
Dogrulananlar: uniform adlari GLSL'deki bildirimlerle eslesiyor mu, doku verisi boyutu, matris boyutlari,
cizim cagrilari, FBO/shader yasam dongusu, tum kare akisi (Shell.render)."""
import os, re, sys, types
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["NEXUS_SIM"] = "1"
import numpy as np

fails = 0
def check(c, m):
    global fails; print(("  ok   " if c else "  FAIL ") + m); fails += 0 if c else 1

class FakeGL:
    def __init__(self):
        self.n = 100; self.src = {}; self.prog_shaders = {}; self.loc = {}; self.locname = {}
        self.set_uniforms = {}; self.calls = {}; self.errors = []; self.cur = None
        self.tex_size = {}; self.bound = None; self.uploads = 0; self.draws = 0
        self.GL_FRAMEBUFFER_COMPLETE = 0x8CD5; self.GL_COMPILE_STATUS = 1; self.GL_LINK_STATUS = 2
    def _id(self): self.n += 1; return self.n
    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        if name.startswith("GL_"):
            v = (abs(hash(name)) % 60000) + 1000; setattr(self, name, v); return v
        def f(*a, **k):
            self.calls[name] = self.calls.get(name, 0) + 1
            return getattr(self, "_" + name, lambda *x: None)(*a)
        return f
    # --- yasam dongusu
    def _glGetString(self, w): return b"Fake GPU (test)"
    def _glCreateShader(self, k): i = self._id(); self.src[i] = ""; return i
    def _glShaderSource(self, sh, s): self.src[sh] = s
    def _glGetShaderiv(self, sh, what): return 1
    def _glGetProgramiv(self, p, what): return 1
    def _glCreateProgram(self): i = self._id(); self.prog_shaders[i] = []; return i
    def _glAttachShader(self, p, sh): self.prog_shaders[p].append(sh)
    def _glUseProgram(self, p): self.cur = p
    def _glGenTextures(self, n): return self._id()
    def _glGenFramebuffers(self, n): return self._id()
    def _glGenVertexArrays(self, n): return self._id()
    def _glGenBuffers(self, n): return self._id()
    def _glCheckFramebufferStatus(self, t): return self.GL_FRAMEBUFFER_COMPLETE
    def _glBindTexture(self, t, tex): self.bound = tex
    def _glTexImage2D(self, t, lvl, ifmt, w, h, border, fmt, typ, data):
        self.tex_size[self.bound] = (w, h)
        if data is not None and len(data) != w * h * 4: self.errors.append("glTexImage2D veri boyutu %d != %d" % (len(data), w * h * 4))
    def _glTexSubImage2D(self, t, lvl, x, y, w, h, fmt, typ, data):
        self.uploads += 1
        if self.tex_size.get(self.bound) != (w, h): self.errors.append("TexSub boyutu doku ile uyusmuyor %s vs %s" % ((w, h), self.tex_size.get(self.bound)))
        if len(data) != w * h * 4: self.errors.append("TexSub veri boyutu %d != %d" % (len(data), w * h * 4))
    def _glDrawArrays(self, mode, first, count): self.draws += 1
    # --- uniform dogrulama
    def _glGetUniformLocation(self, p, name):
        srcs = "\n".join(self.src[s] for s in self.prog_shaders[p])
        if not re.search(r"uniform\s+\w+\s+" + re.escape(name) + r"\b", srcs):
            self.errors.append("uniform '%s' program %d'in GLSL'inde bildirilmemis" % (name, p))
        l = self.loc.setdefault((p, name), self._id()); self.locname[l] = (p, name); return l
    def _uni(self, loc, n, *vals):
        self.set_uniforms.setdefault(self.locname.get(loc, (0, "?")), 0); self.set_uniforms[self.locname[loc]] += 1
    def _glUniform1f(self, l, a): self._uni(l, 1)
    def _glUniform2f(self, l, a, b): self._uni(l, 2)
    def _glUniform3f(self, l, a, b, c): self._uni(l, 3)
    def _glUniform4f(self, l, a, b, c, d): self._uni(l, 4)
    def _glUniform1i(self, l, a): self._uni(l, 1)
    def _glUniformMatrix4fv(self, l, c, t, m):
        if np.asarray(m).size != 16 * c: self.errors.append("mat4 boyutu %s" % np.asarray(m).shape)
        self._uni(l, 16)
    def _glUniformMatrix3fv(self, l, c, t, m):
        if np.asarray(m).size != 9 * c: self.errors.append("mat3 boyutu %s" % np.asarray(m).shape)
        self._uni(l, 9)

fake = FakeGL()
pkg = types.ModuleType("OpenGL"); pkg.GL = fake
sys.modules["OpenGL"] = pkg; sys.modules["OpenGL.GL"] = fake
from nexus import gl as nexgl, catalog
from nexus.shell import Shell
from nexus.bridge import StoreBridge

print("== shader kaynaklari ==")
for name in ("VS_FS", "FS_BLIT", "FS_BLUR", "FS_BG", "VS_CARD", "FS_CARD", "FS_SHADOW"):
    s = getattr(nexgl, name)
    check(s.startswith("#version 330 core") and s.count("{") == s.count("}") and s.count("(") == s.count(")"), "%s: surum satiri + parantez/suslu denge" % name)
check("void main" in nexgl.FS_BG and "oColor" in nexgl.FS_BG, "arka plan shader'i main + cikti iceriyor")

print("== Gfx baslatma / tam kare akisi ==")
W, H = 1600, 900
gfx = nexgl.Gfx(W, H, "high")
check(gfx.renderer == "Fake GPU (test)" and gfx.scale == 1.0, "Gfx baslatildi (renderer okundu)")
check(fake.calls.get("glCreateProgram") == 5, "5 shader programi olusturuldu")
sh = Shell(W, H, gfx, bridge=StoreBridge(sim=True))
for _ in range(90): sh.update(1 / 60)
d0 = fake.draws
for i in range(5):
    sh.update(1 / 60); sh.render(i / 60.0)
per_frame = (fake.draws - d0) / 5
check(not fake.errors, "GL cagrilarinda hata yok: %s" % (fake.errors[:3] or "temiz"))
check(per_frame > 10, "kare basina %d cizim cagrisi (sahne + golge + nesneler)" % per_frame)
check(fake.uploads > 5, "yuzey dokulari GPU'ya yuklendi (%d)" % fake.uploads)
card = nexgl.FS_CARD
used = {n for (p, n), c in fake.set_uniforms.items()}
decl = set(re.findall(r"uniform\s+\w+\s+(\w+)", card + nexgl.VS_CARD))
missing = sorted(decl - used)
check(not missing, "FS_CARD/VS_CARD'daki tum uniform'lar Python'dan ayarlaniyor (eksik: %s)" % missing)
decl_bg = set(re.findall(r"uniform\s+\w+\s+(\w+)", nexgl.FS_BG))
check(decl_bg <= used, "FS_BG uniform'lari ayarlaniyor (eksik: %s)" % sorted(decl_bg - used))
decl_sh = set(re.findall(r"uniform\s+\w+\s+(\w+)", nexgl.FS_SHADOW + nexgl.VS_CARD))
check(decl_sh <= used, "FS_SHADOW uniform'lari ayarlaniyor")

print("== degisen boyutta yuzey (ipucu) + yeniden boyutlandirma ==")
sh.dock.tip.set_text("Cok daha uzun bir ipucu metni"); sh.update(1 / 60); sh.render(1.0)
check(not fake.errors, "ipucu dokusu yeniden olusturuldu, boyut uyumlu")
gfx.resize(1280, 720); sh.render(2.0)
check(not fake.errors and fake.calls.get("glDeleteFramebuffers", 0) >= 3, "resize: eski FBO'lar silindi, yenileri kuruldu")
low = nexgl.Gfx(W, H, "low"); check(low.scale == 0.5, "NEXUS_QUALITY=low -> yari cozunurluk")
print("\nBASARISIZ (%d)" % fails if fails else "\nTUM TESTLER GECTI"); sys.exit(1 if fails else 0)
