import os, sys, time, subprocess, tempfile, stat
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from nexus.bridge import StoreBridge, OK, FAIL
from nexus import catalog

ROOT = os.path.join(os.path.dirname(__file__), "..", "..")
SCRIPT = os.path.abspath(os.path.join(ROOT, "system", "usr", "bin", "nexus-store.sh"))
CATALOG = os.path.abspath(os.path.join(ROOT, "nexus-shell", "data", "catalog.json"))
tmp = tempfile.mkdtemp()
fails = 0
def check(c, m):
    global fails; print(("  ok   " if c else "  FAIL ") + m); fails += 0 if c else 1

# sahte pacman: gercek pacman --noprogressbar cikti bicimini taklit eder, argumanlari kaydeder
fake = os.path.join(tmp, "pacman"); db = os.path.join(tmp, "db"); open(db, "w").write("bash\nlinux\n")
open(fake, "w").write(f"""#!/bin/sh
echo "pacman $@" >> {tmp}/pacman.log
case "$1" in
 -Qq) [ -z "$2" ] && cat {db} && exit 0; grep -qx "$2" {db}; exit $?;;
 -Sy) echo ":: Synchronizing package databases..."; exit 0;;
 -S)  shift; pkg=$(echo "$@" | awk '{{print $NF}}')
      [ "$pkg" = "fail-me" ] && {{ echo "error: target not found: $pkg"; exit 1; }}
      echo "resolving dependencies..."; echo "Packages (3) libfoo-1.0-1  libbar-2.0-1  $pkg-3.0-1"
      echo ":: Retrieving packages..."; for f in libfoo-1.0-1 libbar-2.0-1 $pkg-3.0-1; do echo " $f-x86_64 downloading..."; sleep 0.04; done
      echo "(3/3) checking keys in keyring"; echo "(3/3) checking package integrity"; sleep 0.05
      echo "(1/3) installing libfoo"; sleep 0.05; echo "(2/3) installing libbar"; sleep 0.05; echo "(3/3) installing $pkg"
      echo ":: Running post-transaction hooks..."; echo "$pkg" >> {db}; exit 0;;
 -Rns) shift; pkg=$(echo "$@" | awk '{{print $NF}}'); echo "(1/1) removing $pkg"; grep -vx "$pkg" {db} > {db}.n; mv {db}.n {db}; exit 0;;
esac
""")
os.chmod(fake, 0o755)
env = dict(os.environ, NEXUS_PACMAN=fake, NEXUS_CATALOG=CATALOG, NEXUS_ALLOW_UNPRIV="1", NEXUS_LOCK=os.path.join(tmp, "lock"), NEXUS_SKIP_SYNC="1")
os.environ.update(env)

print("== betik guvenligi ==")
def run(*a): return subprocess.run([SCRIPT, *a], capture_output=True, text=True, env=env)
check(run("install", "mousepad").returncode == 0, "katalogdaki paket kuruldu")
check(run("install", "not-in-catalog").returncode == 2, "katalog disi paket reddedildi (rc=2)")
check(run("install", "firefox; rm -rf /").returncode == 2, "kabuk enjeksiyonu reddedildi")
check(run("install", "-Syu").returncode == 2, "'-' ile baslayan secenek reddedildi")
check(run("install", "$(id)").returncode == 2, "komut yerine koyma reddedildi")
check(run("install", "firefox", "extra").returncode == 2, "fazla arguman reddedildi")
check(run("bogus").returncode == 2, "bilinmeyen komut reddedildi")
check(run("check-online").returncode in (0, 1), "check-online root gerektirmeden calisir (rc 0/1)")
check("sync" not in open(os.path.join(ROOT, "system", "etc", "sudoers.d", "10-nexus-store")).read().split("nexus-store.sh")[1].split("\n")[0], "sudoers: sync yetkisi verilmedi (en az yetki)")
log = open(os.path.join(tmp, "pacman.log")).read()
check("-S --noconfirm --needed --noprogressbar mousepad" in log, "pacman komutu dogru: -S --noconfirm --needed --noprogressbar mousepad")
check("rm -rf" not in log and "-Syu" not in log, "reddedilen girdiler pacman'a hic ulasmadi")
check(run("is-installed", "mousepad").returncode == 0 and run("is-installed", "nope").returncode != 0, "is-installed")

print("== kopru: nexus-store.sh install <paket> ==")
b = StoreBridge(cmd=SCRIPT, sim=False)
b.refresh()
check("bash" in b.installed and "galculator" not in b.installed, "list-installed okundu")
open(os.path.join(tmp, "pacman.log"), "w").close()
check(b.install("galculator"), "install baslatildi")
check(not b.install("htop"), "mesgulken ikinci islem reddedildi")
j = b.job("galculator"); seen = []; t0 = time.time()
while b.busy and time.time() - t0 < 10:
    seen.append((round(j.progress, 2), j.status)); time.sleep(0.01)
time.sleep(0.05)
check(j.state == OK and b.is_installed("galculator"), "kurulum tamamlandi, durum kurulu")
ps = [p for p, _ in seen]
check(all(b <= a2 + 1e-9 for b, a2 in zip(ps, ps[1:])), "ilerleme asla geri gitmiyor (monoton)")
check(any(s.startswith("Downloading") for _, s in seen) and any("installing" in s for _, s in seen), "asamalar goruldu: Downloading -> installing")
check(j.progress == 1.0, "bitince ilerleme %100")
log = open(os.path.join(tmp, "pacman.log")).read()
check("galculator" in log and log.count("galculator") >= 1, "pacman galculator icin cagrildi")
print("== kopru: calisan KOMUT (argv) dogrulamasi ==")
rec = os.path.join(tmp, "rec"); wrapper = os.path.join(tmp, "nexus-store.sh")
open(wrapper, "w").write(f'#!/bin/sh\necho "$@" > {rec}\necho "(1/1) installing x"\nexit 0\n'); os.chmod(wrapper, 0o755)
b2 = StoreBridge(cmd=wrapper, sim=False); b2.install("vlc")
while b2.busy: time.sleep(0.01)
check(open(rec).read().strip() == "install vlc", "tiklama -> 'nexus-store.sh install vlc' (arguman listesi birebir)")
print("== kaldirma + hata yolu ==")
check(b.remove("galculator"), "remove baslatildi")
while b.busy: time.sleep(0.01)
time.sleep(0.05)
check(not b.is_installed("galculator") and b.job("galculator").state == OK, "kaldirma tamamlandi")
# katalog disi paket -> betik rc=2 -> kopru FAIL + hata metni
check(b.install("fail-me"), "olmayan paket icin islem baslatildi")
while b.busy: time.sleep(0.01)
time.sleep(0.05)
jf = b.job("fail-me")
check(jf.state == FAIL and "catalog" in jf.error, "reddedildi -> FAIL, hata kullaniciya iletildi: %r" % jf.error[:60])
print("== simulasyon modu (betik yok) ==")
bs = StoreBridge(cmd="definitely-not-installed.sh"); check(bs.sim, "betik yoksa simulasyon")
bs.install("vlc"); t0 = time.time()
while bs.busy and time.time() - t0 < 10: time.sleep(0.05)
check(bs.job("vlc").state == OK and bs.is_installed("vlc"), "simulasyon kurulumu tamam")
print("== katalog ==")
apps = catalog.load(CATALOG)
check(all(a.category in ("Utilities", "Games", "Development", "Media") for a in apps), "kategoriler gecerli")
check(len(catalog.filter_apps(apps, "Games")) == 4 and len(catalog.filter_apps(apps, "Discover", "vlc")) == 1, "filtre + arama")
check(len(catalog.filter_apps(apps, "Installed", installed={"git", "vlc"})) == 2, "Installed filtresi")
print("\nBASARISIZ (%d)" % fails if fails else "\nTUM TESTLER GECTI"); sys.exit(1 if fails else 0)
