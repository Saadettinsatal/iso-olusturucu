"""ui.py -- immediate-mode widget yardimcilari (yay animasyonlu hover/press)."""
from .spring import Spring
from . import theme as T


class UI:
    def __init__(self):
        self.hov = {}
        self.hits = []
        self.mouse = None
        self.down = False
        self.c = None

    def begin(self, canvas, mouse, down):
        self.c, self.mouse, self.down, self.hits = canvas, mouse, down, []

    def _sp(self, key):
        s = self.hov.get(key)
        if s is None:
            s = self.hov[key] = Spring(0.0, k=320.0, c=26.0)
        return s

    def region(self, key, x, y, w, h, enabled=True):
        """Tiklanabilir bolge kaydet; (hover_yayi 0..1, fare_ustunde) dondur."""
        if enabled:
            self.hits.append((key, (x, y, w, h)))
        m = self.mouse
        hot = bool(enabled and m and x <= m[0] < x + w and y <= m[1] < y + h)
        s = self._sp(key)
        s.t = 1.0 if hot else 0.0
        return s.x, hot

    def hit(self, px, py):
        for key, (x, y, w, h) in reversed(self.hits):
            if x <= px < x + w and y <= py < y + h:
                return key
        return None

    def step(self, dt):
        active = False
        for s in self.hov.values():
            s.step(dt)
            if not s.at_rest():
                active = True
        return active

    # ------------------------------------------------------------ widget'lar
    def button(self, key, x, y, w, h, label, kind="primary", enabled=True, size=13):
        e, hot = self.region(key, x, y, w, h, enabled)
        c = self.c
        press = hot and self.down
        e = max(0.0, e)
        inset = 2 if press else 0
        yo = -1.2 * e
        bx, by, bw, bh = x + inset, y + yo + inset, w - 2 * inset, h - 2 * inset
        r = bh // 2
        if not enabled:
            c.rrect(bx, by, bw, bh, r, fill=(255, 255, 255, 14))
            c.text(x + w / 2, y + (h - size * 1.3) / 2, label, size, T.DIM, "bold", "c")
            return
        if kind == "primary":
            if e > 0.02:
                c.glow(bx, by, bw, bh, r, T.alpha(T.BLUE, 120 * e), 9)
            top = T.mix(T.BLUE, T.WHITE, 0.15 * e)
            bot = T.mix(T.PURPLE, T.WHITE, 0.15 * e)
            c.rrect(bx, by, bw, bh, r, grad=(top, bot), horiz=True)
            c.rrect(bx, by, bw, bh, r, border=(255, 255, 255, int(50 + 60 * e)))
            col = T.hexc("0B1220")
        else:
            base = {"ghost": T.WHITE, "danger": T.BAD, "ok": T.GOOD}[kind]
            if e > 0.02 and kind != "ghost":
                c.glow(bx, by, bw, bh, r, T.alpha(base, 90 * e), 8)
            c.rrect(bx, by, bw, bh, r, fill=T.alpha(base, (14 if kind == "ghost" else 34) + 30 * e),
                    border=T.alpha(base, (40 if kind == "ghost" else 130) + 60 * e))
            col = T.TEXT if kind == "ghost" else base
        c.text(x + w / 2, by + (bh - size * 1.3) / 2, label, size, col, "bold", "c")

    def stars(self, x, y, rating, size=13):
        c = self.c
        for i in range(5):
            if rating >= i + 0.75:
                col = T.WARN
            elif rating >= i + 0.25:
                col = T.mix(T.DIM, T.WARN, 0.55)
            else:
                col = T.DIM
            c.text(x + i * (size + 1), y, "\u2605", size, col, "sym")
        return 5 * (size + 1)

    def bar(self, x, y, w, h, frac, colors=None):
        c = self.c
        c.rrect(x, y, w, h, h // 2, fill=(255, 255, 255, 26))
        fw = max(h, int(w * max(0.0, min(1.0, frac))))
        if frac > 0.001:
            col = colors or (T.BLUE, T.PURPLE)
            c.glow(x, y, fw, h, h // 2, T.alpha(col[0], 70), 6)
            c.rrect(x, y, fw, h, h // 2, grad=col, horiz=True)

    def tile(self, x, y, size, glyph, grad, glyph_size=None):
        """Gradyan simge karosu + sembol."""
        c = self.c
        c.rrect(x, y, size, size, size * 0.28, grad=grad)
        c.rrect(x, y, size, size, size * 0.28, border=(255, 255, 255, 70))
        gs = glyph_size or int(size * 0.5)
        c.text(x + size / 2, y + (size - gs * 1.3) / 2 + 1, glyph, gs, (255, 255, 255, 245), "sym", "c")
