"""sysinfo.py -- /proc tabanli sistem bilgisi (CPU, RAM, disk, ag, uptime)."""
import os
import platform
import socket
import subprocess
import time


class SysInfo:
    def __init__(self):
        self.cpu = self.mem = self.disk = 0.0
        self.mem_total_mb = self.mem_used_mb = 0
        self.net_rx = self.net_tx = 0.0
        self.uptime = 0.0
        self.load1 = 0.0
        self.online = False
        self._cpu_prev = None
        self._net_prev = None

    def poll(self):
        self._cpu(); self._mem(); self._disk(); self._misc(); self._net()

    def _cpu(self):
        try:
            with open("/proc/stat") as f:
                v = [int(x) for x in f.readline().split()[1:9]]
        except (OSError, ValueError):
            return
        idle, total = v[3] + v[4], sum(v)
        if self._cpu_prev:
            dt, di = total - self._cpu_prev[0], idle - self._cpu_prev[1]
            if dt > 0:
                self.cpu = max(0.0, min(1.0, 1.0 - di / dt))
        self._cpu_prev = (total, idle)

    def _mem(self):
        try:
            d = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    k, _, rest = line.partition(":")
                    if k in ("MemTotal", "MemAvailable"):
                        d[k] = int(rest.split()[0])
            tot, av = d["MemTotal"], d["MemAvailable"]
            self.mem_total_mb, self.mem_used_mb = tot // 1024, (tot - av) // 1024
            self.mem = (tot - av) / tot
        except (OSError, KeyError, ValueError, ZeroDivisionError):
            pass

    def _disk(self):
        try:
            s = os.statvfs("/")
            self.disk = 1.0 - s.f_bavail / s.f_blocks if s.f_blocks else 0.0
        except OSError:
            pass

    def _misc(self):
        try:
            with open("/proc/uptime") as f:
                self.uptime = float(f.read().split()[0])
            with open("/proc/loadavg") as f:
                self.load1 = float(f.read().split()[0])
        except (OSError, ValueError):
            pass

    def _net(self):
        rx = tx = 0
        up = False
        try:
            with open("/proc/net/dev") as f:
                for line in list(f)[2:]:
                    name, _, rest = line.partition(":")
                    name = name.strip()
                    if name == "lo":
                        continue
                    p = rest.split()
                    rx += int(p[0]); tx += int(p[8])
            for n in os.listdir("/sys/class/net"):
                if n != "lo":
                    try:
                        with open("/sys/class/net/%s/operstate" % n) as f:
                            up = up or f.read().strip() == "up"
                    except OSError:
                        pass
        except (OSError, ValueError, IndexError):
            return
        self.online = up
        now = time.monotonic()
        if self._net_prev:
            t0, r0, x0 = self._net_prev
            if now > t0:
                self.net_rx = max(0.0, (rx - r0) / (now - t0))
                self.net_tx = max(0.0, (tx - x0) / (now - t0))
        self._net_prev = (now, rx, tx)


def os_field(key, default=""):
    try:
        with open("/etc/os-release") as f:
            for line in f:
                if line.startswith(key + "="):
                    return line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    return default


def kernel():
    u = platform.uname()
    return "%s %s" % (u.release, u.machine)


def hostname():
    return socket.gethostname()


def fmt_uptime(s):
    s = int(s); h, m = s // 3600, s % 3600 // 60
    return "%dh %02dm" % (h, m) if h else "%dm %02ds" % (m, s % 60)


def fmt_rate(bps):
    for unit in ("B/s", "KB/s", "MB/s", "GB/s"):
        if bps < 1024 or unit == "GB/s":
            return "%.1f %s" % (bps, unit) if unit != "B/s" else "%d B/s" % bps
        bps /= 1024.0


def power(action):
    """'poweroff' | 'reboot'. Oturum kullanicisi (nexus) sudoers kuraliyla yetkilidir."""
    argv = ["systemctl", action] if os.geteuid() == 0 else ["sudo", "-n", "systemctl", action]
    try:
        subprocess.Popen(argv, stdin=subprocess.DEVNULL)
    except OSError:
        pass
