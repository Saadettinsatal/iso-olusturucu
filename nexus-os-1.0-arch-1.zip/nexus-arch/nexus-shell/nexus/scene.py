"""scene.py -- kamera, nesne agaci, 3D secim (picking) ve cizim sirasi."""
import math
from . import mathx as M
from .spring import Spring

FOV = 40.0
NEAR, FAR = 10.0, 12000.0


class Camera:
    """Dunya birimi = z=0 duzleminde 1 piksel. Fare ile hafif parallax salinimi."""

    def __init__(self, w, h):
        self.sx = Spring(0.0, k=38.0, c=9.0)
        self.sy = Spring(0.0, k=38.0, c=9.0)
        self.set_size(w, h)

    def set_size(self, w, h):
        self.w, self.h = w, h
        self.cz = (h / 2.0) / math.tan(math.radians(FOV) / 2.0)

    def sway(self, mx, my):
        self.sx.t = -(mx / self.w - 0.5) * 70.0
        self.sy.t = (my / self.h - 0.5) * 36.0

    def step(self, dt):
        self.sx.step(dt)
        self.sy.step(dt)

    @property
    def eye(self):
        return (self.sx.x, 60.0 + self.sy.x, self.cz)

    def matrices(self):
        view = M.look_at(self.eye, (0.0, 0.0, 0.0))
        proj = M.perspective(FOV, self.w / self.h, NEAR, FAR)
        vp = M.mul(proj, view)
        return view, proj, vp, M.inverse(vp)


class Scene:
    def __init__(self, w, h):
        self.cam = Camera(w, h)
        self.roots = []        # 3D nesneler (parent'lar once)
        self.overlay = []      # ekran uzayi nesneleri (ust cubuk)
        self.view = self.proj = self.vp = self.inv_vp = None
        self.refresh_matrices()

    def resize(self, w, h):
        self.cam.set_size(w, h)

    def refresh_matrices(self):
        self.view, self.proj, self.vp, self.inv_vp = self.cam.matrices()

    # ------------------------------------------------------------ nesne yonetimi
    def add(self, obj):
        if obj not in self.roots:
            self.roots.append(obj)

    def remove(self, obj):
        if obj in self.roots:
            self.roots.remove(obj)

    def flat(self):
        """Tum gorunur 3D nesneler: parent -> cocuklar (kids) sirasiyla."""
        out = []

        def walk(o):
            if not o.visible:
                return
            out.append(o)
            for k in getattr(o, "kids", ()):
                k.parent = o
                walk(k)
        for r in self.roots:
            walk(r)
        return out

    def update(self, dt, mouse):
        if mouse:
            self.cam.sway(*mouse)
        self.cam.step(dt)
        self.refresh_matrices()
        objs = self.flat()
        for o in objs:
            o.update(dt)
            o.update_matrix()
        for o in self.overlay:
            o.update(dt)
        return objs

    # ------------------------------------------------------------ secim
    def ray(self, mx, my):
        return M.unproject_ray(self.inv_vp, self.cam.eye, mx, my, self.cam.w, self.cam.h)

    def pick(self, mx, my, objs=None):
        """En one gelen nesneyi bul: (obj, px, py, t) | None. Ust cubuk (overlay) en onde."""
        for o in reversed(self.overlay):
            if o.visible:
                px, py = mx - (o.pos.x - o.w / 2.0), my - (o.pos.y - o.h / 2.0)
                if 0 <= px < o.w and 0 <= py < o.h:
                    return o, px, py, 0.0
        origin, d = self.ray(mx, my)
        best = None
        for o in (objs if objs is not None else self.flat()):
            if getattr(o, "no_pick", False) or o.alpha.x < 0.25:
                continue
            lo, ld = M.ray_to_local(o.inv, origin, d)
            h = M.ray_plane_z0(lo, ld)
            if not h or h[0] <= 0:
                continue
            t, lx, ly = h
            if abs(lx) <= o.w / 2.0 and abs(ly) <= o.h / 2.0:
                if best is None or t < best[3]:
                    px, py = o.to_local_px(lx, ly)
                    best = (o, px, py, t)
        return best

    def world_on_plane(self, mx, my, plane_z):
        origin, d = self.ray(mx, my)
        r = M.ray_plane_world(origin, d, plane_z)
        return r[0] if r else None

    def draw_order(self, objs):
        """Uzaktan yakina (painter): gorunum uzayi z'si kucuk olan once."""
        keyed = []
        for o in objs:
            if o.alpha.x < 0.01:
                continue
            z = M.transform(M.mul(self.view, o._model), (0.0, 0.0, 0.0))[2]
            keyed.append((z, o))
        keyed.sort(key=lambda kv: kv[0])
        return [o for _, o in keyed]
