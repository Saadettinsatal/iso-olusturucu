"""catalog.py -- uygulama katalogu (JSON) ve filtreleme."""
import json
import os
from dataclasses import dataclass

CATEGORIES = ["Discover", "Utilities", "Games", "Development", "Media", "Installed"]
SEARCH_PATHS = ["/usr/share/nexus-os/catalog.json"]


@dataclass
class AppEntry:
    id: str
    name: str
    category: str
    pkg: str
    rating: float
    size_mb: int
    featured: bool
    glyph: str
    exec: str
    tagline: str
    description: str


def find_catalog():
    env = os.environ.get("NEXUS_CATALOG")
    cands = ([env] if env else []) + SEARCH_PATHS + [
        os.path.join(os.path.dirname(__file__), "..", "data", "catalog.json")]
    for p in cands:
        if p and os.path.exists(p):
            return p
    raise FileNotFoundError("catalog.json bulunamadi")


def load(path=None):
    with open(path or find_catalog(), encoding="utf-8") as f:
        data = json.load(f)
    apps = []
    for a in data["apps"]:
        apps.append(AppEntry(a["id"], a["name"], a["category"], a["pkg"], float(a["rating"]), int(a["size_mb"]),
                             bool(a.get("featured")), a.get("glyph", "\u25c6"), a.get("exec", ""),
                             a.get("tagline", ""), a.get("description", "")))
    return apps


def filter_apps(apps, category="Discover", query="", installed=None):
    q = query.strip().lower()
    out = []
    for a in apps:
        if category == "Installed":
            if not (installed and a.pkg in installed):
                continue
        elif category not in ("Discover", "") and a.category != category:
            continue
        if q and q not in a.name.lower() and q not in a.tagline.lower() and q not in a.pkg.lower():
            continue
        out.append(a)
    return out
