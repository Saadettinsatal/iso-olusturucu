"""spring.py -- yay fizigi (yari-oruk Euler, alt adimli, kararli)."""

class Spring:
    __slots__ = ("x", "v", "t", "k", "c")
    def __init__(self, x=0.0, k=220.0, c=22.0):
        self.x = self.t = float(x); self.v = 0.0; self.k = k; self.c = c
    def set(self, x):                       # aninda (animasyonsuz) ata
        self.x = self.t = float(x); self.v = 0.0
    def step(self, dt):
        n = max(1, int(dt / 0.008) + 1)     # buyuk dt'de bile kararli kalmak icin alt adim
        h = dt / n
        for _ in range(n):
            self.v += ((self.t - self.x) * self.k - self.v * self.c) * h
            self.x += self.v * h
        return self.x
    def at_rest(self, eps=0.002):
        return abs(self.t - self.x) < eps and abs(self.v) < eps * 4

class Spring3:
    def __init__(self, x=0.0, y=0.0, z=0.0, k=220.0, c=22.0):
        self.a = (Spring(x, k, c), Spring(y, k, c), Spring(z, k, c))
    @property
    def x(self): return self.a[0].x
    @property
    def y(self): return self.a[1].x
    @property
    def z(self): return self.a[2].x
    def set(self, x, y, z):
        for s, v in zip(self.a, (x, y, z)): s.set(v)
    def to(self, x, y, z):
        for s, v in zip(self.a, (x, y, z)): s.t = float(v)
    def step(self, dt):
        for s in self.a: s.step(dt)
    def at_rest(self, eps=0.002):
        return all(s.at_rest(eps) for s in self.a)

# hazir "his" ayarlari
SNAPPY = dict(k=320.0, c=28.0)      # hizli, az tasma
SOFT   = dict(k=110.0, c=16.0)      # yavas, yumusak
BOUNCY = dict(k=260.0, c=14.0)      # belirgin tasma (dock, kartlar)
