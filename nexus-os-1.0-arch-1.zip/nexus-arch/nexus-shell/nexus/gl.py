"""gl.py -- Modern OpenGL 3.3 core boru hatti (PyOpenGL).

Kare akisi:
  1. 3D arka plan (kameradan isin izleme: neon zemin, gunes, yuzen kureler) -> FBO
  2. FBO'yu 1/4 cozunurluge indirip bulaniklastir -> "buzlu cam" arka plani
  3. Arka plani ekrana ciz, zemine dusen gercek 3D golgeleri ciz
  4. Nesneleri uzaktan yakina ciz: cam levha + Pillow dokusu + bevel/speküler/fresnel isik
"""
import math

import numpy as np
from OpenGL import GL as gl

from . import mathx as M

# --------------------------------------------------------------------------- GLSL
VS_FS = """#version 330 core
layout(location=0) in vec2 aPos;
out vec2 vUV;
void main(){ vUV = aPos + 0.5; gl_Position = vec4(aPos * 2.0, 0.0, 1.0); }
"""

FS_BLIT = """#version 330 core
in vec2 vUV; uniform sampler2D uTex; out vec4 oColor;
void main(){ oColor = vec4(texture(uTex, vUV).rgb, 1.0); }
"""

FS_BLUR = """#version 330 core
in vec2 vUV; uniform sampler2D uTex; uniform vec2 uDir; out vec4 oColor;
void main(){
  vec3 c = texture(uTex, vUV).rgb * 0.2270270270;
  c += (texture(uTex, vUV + uDir*1.3846153846).rgb + texture(uTex, vUV - uDir*1.3846153846).rgb) * 0.3162162162;
  c += (texture(uTex, vUV + uDir*3.2307692308).rgb + texture(uTex, vUV - uDir*3.2307692308).rgb) * 0.0702702703;
  oColor = vec4(c, 1.0);
}
"""

FS_BG = """#version 330 core
in vec2 vUV;
uniform mat4 uInvVP; uniform vec3 uCam; uniform float uTime; uniform vec3 uA1; uniform vec3 uA2; uniform float uFloorY;
out vec4 oColor;
float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void main(){
  vec2 ndc = vUV * 2.0 - 1.0;
  vec4 p = uInvVP * vec4(ndc, 1.0, 1.0); p /= p.w;
  vec3 ro = uCam; vec3 rd = normalize(p.xyz - ro);
  vec3 navy = vec3(0.059, 0.090, 0.165);
  vec3 horizon = vec3(0.24, 0.10, 0.40);
  float h = clamp(rd.y, 0.0, 1.0);
  vec3 col = mix(horizon, navy, pow(h, 0.4));
  col = mix(col, vec3(0.02, 0.03, 0.07), smoothstep(0.35, 0.9, h));
  // yildizlar
  vec2 sp = vec2(atan(rd.x, -rd.z) * 38.0, rd.y * 70.0);
  float r = hash(floor(sp));
  col += step(0.987, r) * (0.5 + 0.5 * sin(uTime * 2.0 + r * 40.0)) * smoothstep(0.03, 0.3, rd.y);
  // gunes
  vec3 sd = normalize(vec3(0.0, 0.07, -1.0));
  float sdot = dot(rd, sd);
  float sun = smoothstep(0.9983, 0.9987, sdot);
  float band = step(0.0, sin(rd.y * 380.0 - uTime * 0.8) + (rd.y - 0.045) * 30.0);
  col += sun * mix(vec3(1.0, 0.45, 0.55), uA2, 0.4) * 1.25 * band;
  col += uA2 * 0.30 * pow(max(sdot, 0.0), 90.0);
  // zemin (3D izgara). fwidth() turevleri dallanan akista tanimsizdir; bu yuzden
  // dalin DISINDA, her piksel icin guvenli bir t ile hesaplanir.
  float tf = (uFloorY - ro.y) / min(rd.y, -0.0003);
  vec2 gpf = (ro + rd * tf).xz / 150.0; gpf.y += uTime * 0.12;
  vec2 fwf = fwidth(gpf);
  if (rd.y < -0.0003) {
    float t = tf;
    vec3 hp = ro + rd * t;
    vec2 gp = gpf;
    vec2 gr = abs(fract(gp - 0.5) - 0.5) / max(fwf, vec2(1e-5));
    float line = 1.0 - min(min(gr.x, gr.y), 1.0);
    float fog = exp(-t * 0.00055);
    vec3 neon = mix(uA1, uA2, smoothstep(-2500.0, 2500.0, hp.x));
    vec3 fc = vec3(0.025, 0.04, 0.09) + neon * line * 0.95 * fog + neon * 0.05 * fog
            + mix(uA2, uA1, 0.5) * 0.20 * exp(-t * 0.0009);
    col = mix(horizon * 0.55, fc, clamp(fog * 1.5, 0.0, 1.0));
  }
  // yuzen kureler (gercek 3D isin-kure kesisimi)
  for (int i = 0; i < 5; i++) {
    float fi = float(i);
    vec3 c = vec3(sin(uTime * 0.12 + fi * 1.9) * 1300.0, 140.0 + 110.0 * sin(uTime * 0.17 + fi * 2.3), -700.0 - fi * 420.0);
    float rad = 95.0 + fi * 22.0;
    vec3 oc = ro - c; float b = dot(oc, rd); float cc = dot(oc, oc) - rad * rad; float disc = b * b - cc;
    vec3 ocol = mix(uA1, uA2, fi / 4.0);
    float dist = sqrt(max(dot(oc, oc) - b * b, 0.0));
    if (b < 0.0) col += ocol * exp(-max(dist - rad, 0.0) / (rad * 0.55)) * 0.20;
    if (disc > 0.0) {
      float tt = -b - sqrt(disc);
      if (tt > 0.0) {
        vec3 n = normalize(oc + rd * tt);
        float diff = max(dot(n, normalize(vec3(-0.5, 0.7, 0.6))), 0.0);
        float fr = pow(1.0 - max(dot(n, -rd), 0.0), 2.5);
        col = mix(col, ocol * (0.18 + 0.85 * diff) + ocol * fr * 0.9 + 0.06, 0.92);
      }
    }
  }
  col *= 1.0 - 0.32 * dot(ndc, ndc) * 0.5;
  oColor = vec4(col, 1.0);
}
"""

VS_CARD = """#version 330 core
layout(location=0) in vec2 aPos;
uniform mat4 uMVP; uniform mat4 uModel; uniform vec2 uSize; uniform float uPad;
out vec2 vLocal; out vec3 vWorld;
void main(){
  vec2 p = aPos * (uSize + vec2(2.0 * uPad));
  vLocal = p;
  vWorld = (uModel * vec4(p, 0.0, 1.0)).xyz;
  gl_Position = uMVP * vec4(p, 0.0, 1.0);
}
"""

FS_CARD = """#version 330 core
in vec2 vLocal; in vec3 vWorld;
uniform sampler2D uTex; uniform sampler2D uBlur;
uniform vec2 uSize; uniform float uRadius; uniform float uAlpha; uniform float uDim;
uniform vec4 uTint; uniform float uGlass; uniform float uBevel; uniform float uRim;
uniform vec3 uGlow; uniform float uGlowAmt; uniform vec2 uScreen;
uniform vec3 uCam; uniform vec3 uLight; uniform mat3 uRot; uniform float uFlat;
out vec4 oColor;
float sdRound(vec2 p, vec2 b, float r){ vec2 q = abs(p) - b + r; return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r; }
float sdf(vec2 p){ return sdRound(p, uSize * 0.5, uRadius); }
void main(){
  float d = sdf(vLocal);
  float aa = 1.0 - smoothstep(-1.0, 1.0, d);
  float g = uGlowAmt * exp(-max(d, 0.0) / 18.0);
  vec4 outer = vec4(uGlow * g, g * 0.85);
  if (aa <= 0.002) { oColor = outer * uAlpha; return; }
  vec2 uv = vec2(vLocal.x / uSize.x + 0.5, 0.5 - vLocal.y / uSize.y);
  vec4 c = texture(uTex, clamp(uv, 0.0, 1.0));            // premultiplied
  vec3 bg = texture(uBlur, gl_FragCoord.xy / uScreen).rgb;
  vec3 base = mix(uTint.rgb, mix(bg, uTint.rgb, uTint.a), uGlass);
  // bevel normali: SDF gradyani kenara yaklastikca disa dogru yatar
  float e = 1.0;
  vec2 grad = vec2(sdf(vLocal + vec2(e, 0.0)) - sdf(vLocal - vec2(e, 0.0)),
                   sdf(vLocal + vec2(0.0, e)) - sdf(vLocal - vec2(0.0, e)));
  float bev = smoothstep(-uBevel, 0.0, d);
  vec3 nl = normalize(vec3(grad * bev * 1.2, 1.0));
  vec3 N = normalize(uRot * nl);
  vec3 V = normalize(uCam - vWorld);
  vec3 L = normalize(uLight - vWorld);
  if (uFlat > 0.5) { N = vec3(0.0, 0.0, 1.0); V = vec3(0.0, 0.0, 1.0); L = normalize(vec3(-0.3, 0.5, 0.8)); }
  float diff = clamp(dot(N, L), 0.0, 1.0);
  float spec = pow(max(dot(reflect(-L, N), V), 0.0), 36.0);
  float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 2.2);
  vec3 col = base * (0.78 + 0.34 * diff);
  col += vec3(0.07, 0.09, 0.14) * smoothstep(-0.2, 0.5, vLocal.y / uSize.y) * 0.8;   // ust parilti
  col = col * (1.0 - c.a) + c.rgb;                                                    // icerik cam uzerinde
  col += spec * (0.25 + 0.9 * bev) * vec3(0.85, 0.93, 1.0) * 0.55;
  col += fres * uRim * uGlow * 0.45;
  float ring = smoothstep(-1.8, -0.6, d) * (1.0 - smoothstep(-0.6, 0.8, d));
  col = mix(col, uGlow * 1.1 + 0.25, ring * (0.28 + 0.55 * uGlowAmt));
  col *= uDim;
  vec4 inner = vec4(col, 1.0) * aa;
  oColor = (inner + outer * (1.0 - aa)) * uAlpha;
}
"""

FS_SHADOW = """#version 330 core
in vec2 vLocal; in vec3 vWorld;
uniform vec2 uSize; uniform float uSoft; uniform float uOpacity;
out vec4 oColor;
float sdRound(vec2 p, vec2 b, float r){ vec2 q = abs(p) - b + r; return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r; }
void main(){
  vec2 b = uSize * 0.5 - vec2(uSoft);
  float d = sdRound(vLocal, b, min(min(b.x, b.y), 40.0));
  oColor = vec4(0.0, 0.0, 0.0, (1.0 - smoothstep(-uSoft, uSoft, d)) * uOpacity);
}
"""


def _compile(src, kind):
    sh = gl.glCreateShader(kind)
    gl.glShaderSource(sh, src)
    gl.glCompileShader(sh)
    if not gl.glGetShaderiv(sh, gl.GL_COMPILE_STATUS):
        raise RuntimeError("shader derlenemedi:\n" + gl.glGetShaderInfoLog(sh).decode(errors="replace"))
    return sh


class Program:
    def __init__(self, vs, fs):
        self.id = gl.glCreateProgram()
        v, f = _compile(vs, gl.GL_VERTEX_SHADER), _compile(fs, gl.GL_FRAGMENT_SHADER)
        gl.glAttachShader(self.id, v)
        gl.glAttachShader(self.id, f)
        gl.glLinkProgram(self.id)
        if not gl.glGetProgramiv(self.id, gl.GL_LINK_STATUS):
            raise RuntimeError("program baglanamadi:\n" + gl.glGetProgramInfoLog(self.id).decode(errors="replace"))
        gl.glDeleteShader(v)
        gl.glDeleteShader(f)
        self._loc = {}

    def use(self):
        gl.glUseProgram(self.id)

    def loc(self, name):
        l = self._loc.get(name)
        if l is None:
            l = self._loc[name] = gl.glGetUniformLocation(self.id, name)
        return l

    def f(self, name, *v):
        {1: gl.glUniform1f, 2: gl.glUniform2f, 3: gl.glUniform3f, 4: gl.glUniform4f}[len(v)](self.loc(name), *v)

    def i(self, name, v):
        gl.glUniform1i(self.loc(name), v)

    def m4(self, name, m):
        gl.glUniformMatrix4fv(self.loc(name), 1, gl.GL_TRUE, np.array(m, dtype=np.float32))

    def m3(self, name, m):
        gl.glUniformMatrix3fv(self.loc(name), 1, gl.GL_TRUE, np.array(m, dtype=np.float32))


class Target:
    def __init__(self, w, h):
        self.w, self.h = max(2, int(w)), max(2, int(h))
        self.tex = gl.glGenTextures(1)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self.tex)
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, self.w, self.h, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, None)
        for k, v in ((gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR), (gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR),
                     (gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE), (gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)):
            gl.glTexParameteri(gl.GL_TEXTURE_2D, k, v)
        self.fbo = gl.glGenFramebuffers(1)
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, self.fbo)
        gl.glFramebufferTexture2D(gl.GL_FRAMEBUFFER, gl.GL_COLOR_ATTACHMENT0, gl.GL_TEXTURE_2D, self.tex, 0)
        if gl.glCheckFramebufferStatus(gl.GL_FRAMEBUFFER) != gl.GL_FRAMEBUFFER_COMPLETE:
            raise RuntimeError("FBO tamamlanmadi")
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, 0)

    def bind(self):
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, self.fbo)
        gl.glViewport(0, 0, self.w, self.h)

    def free(self):
        gl.glDeleteFramebuffers(1, [self.fbo])
        gl.glDeleteTextures([self.tex])


def _rot3(m):
    """Model matrisinin donus kismi (olcek cikarilmis), satir-oncelikli 3x3."""
    cols = []
    for j in range(3):
        v = (m[j], m[4 + j], m[8 + j])
        l = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
        cols.append((v[0] / l, v[1] / l, v[2] / l))
    return [cols[0][0], cols[1][0], cols[2][0], cols[0][1], cols[1][1], cols[2][1], cols[0][2], cols[1][2], cols[2][2]]


class Gfx:
    LIGHT = (-700.0, 1100.0, 900.0)

    def __init__(self, w, h, quality="high"):
        self.renderer = gl.glGetString(gl.GL_RENDERER).decode(errors="replace")
        soft = any(k in self.renderer.lower() for k in ("llvmpipe", "softpipe", "swrast"))
        self.scale = 0.5 if (quality == "low" or soft) else 1.0
        self.p_fs_blit = Program(VS_FS, FS_BLIT)
        self.p_blur = Program(VS_FS, FS_BLUR)
        self.p_bg = Program(VS_FS, FS_BG)
        self.p_card = Program(VS_CARD, FS_CARD)
        self.p_shadow = Program(VS_CARD, FS_SHADOW)
        quad = np.array([-0.5, -0.5, 0.5, -0.5, -0.5, 0.5, 0.5, 0.5], dtype=np.float32)
        self.vao = gl.glGenVertexArrays(1)
        gl.glBindVertexArray(self.vao)
        vbo = gl.glGenBuffers(1)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, vbo)
        gl.glBufferData(gl.GL_ARRAY_BUFFER, quad.nbytes, quad, gl.GL_STATIC_DRAW)
        gl.glEnableVertexAttribArray(0)
        gl.glVertexAttribPointer(0, 2, gl.GL_FLOAT, gl.GL_FALSE, 0, None)
        self.targets = []
        self.blank = None
        gl.glDisable(gl.GL_DEPTH_TEST)
        gl.glEnable(gl.GL_BLEND)
        gl.glBlendFunc(gl.GL_ONE, gl.GL_ONE_MINUS_SRC_ALPHA)          # premultiplied alpha
        self.resize(w, h)

    def resize(self, w, h):
        for t in self.targets:
            t.free()
        self.W, self.H = int(w), int(h)
        sw, sh = int(w * self.scale), int(h * self.scale)
        self.scene_t = Target(sw, sh)
        self.ping = Target(max(64, sw // 4), max(64, sh // 4))
        self.pong = Target(max(64, sw // 4), max(64, sh // 4))
        self.targets = [self.scene_t, self.ping, self.pong]

    def _quad(self):
        gl.glDrawArrays(gl.GL_TRIANGLE_STRIP, 0, 4)

    def _bind_tex(self, unit, tex):
        gl.glActiveTexture(gl.GL_TEXTURE0 + unit)
        gl.glBindTexture(gl.GL_TEXTURE_2D, tex)

    # ------------------------------------------------------------ arka plan + bulaniklik
    def background(self, scene, t, a1, a2, floor_y):
        view, proj, vp, inv_vp = scene.view, scene.proj, scene.vp, scene.inv_vp
        gl.glDisable(gl.GL_BLEND)
        self.scene_t.bind()
        p = self.p_bg
        p.use()
        p.m4("uInvVP", inv_vp)
        p.f("uCam", *scene.cam.eye)
        p.f("uTime", t)
        p.f("uA1", *a1)
        p.f("uA2", *a2)
        p.f("uFloorY", floor_y)
        self._quad()
        # kucult + bulaniklastir (iki tur)
        self.p_fs_blit.use()
        self.p_fs_blit.i("uTex", 0)
        self.ping.bind()
        self._bind_tex(0, self.scene_t.tex)
        self._quad()
        self.p_blur.use()
        self.p_blur.i("uTex", 0)
        for _ in range(2):
            self.pong.bind()
            self._bind_tex(0, self.ping.tex)
            self.p_blur.f("uDir", 1.0 / self.ping.w, 0.0)
            self._quad()
            self.ping.bind()
            self._bind_tex(0, self.pong.tex)
            self.p_blur.f("uDir", 0.0, 1.0 / self.ping.h)
            self._quad()
        # ekrana
        gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, 0)
        gl.glViewport(0, 0, self.W, self.H)
        self.p_fs_blit.use()
        self._bind_tex(0, self.scene_t.tex)
        self._quad()
        gl.glEnable(gl.GL_BLEND)

    # ------------------------------------------------------------ dokular
    def upload(self, obj):
        if obj.no_tex:
            if self.blank is None:
                self.blank = gl.glGenTextures(1)
                gl.glBindTexture(gl.GL_TEXTURE_2D, self.blank)
                gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, 1, 1, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE,
                                bytes(4))
                gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MIN_FILTER, gl.GL_NEAREST)
                gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MAG_FILTER, gl.GL_NEAREST)
            obj.tex = self.blank
            return
        wh = (obj.canvas.w, obj.canvas.h)
        fresh = obj.tex is None or getattr(obj, "_tex_wh", None) != wh
        if fresh:
            if obj.tex is not None and obj.tex != self.blank:
                gl.glDeleteTextures([obj.tex])
            obj.tex = gl.glGenTextures(1)
            obj._tex_wh = wh
            gl.glBindTexture(gl.GL_TEXTURE_2D, obj.tex)
            for k, v in ((gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR_MIPMAP_LINEAR), (gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR),
                         (gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE), (gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)):
                gl.glTexParameteri(gl.GL_TEXTURE_2D, k, v)
            gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, wh[0], wh[1], 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, None)
            obj.gpu_dirty = True
        if obj.gpu_dirty:
            gl.glBindTexture(gl.GL_TEXTURE_2D, obj.tex)
            data = obj.canvas.img.convert("RGBa").tobytes()            # premultiplied alpha
            gl.glPixelStorei(gl.GL_UNPACK_ALIGNMENT, 1)
            gl.glTexSubImage2D(gl.GL_TEXTURE_2D, 0, 0, 0, wh[0], wh[1], gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, data)
            gl.glGenerateMipmap(gl.GL_TEXTURE_2D)
            obj.gpu_dirty = False

    # ------------------------------------------------------------ golgeler (zemine)
    def shadows(self, scene, objs, floor_y):
        p = self.p_shadow
        p.use()
        p.m4("uModel", M.ident())
        p.f("uPad", 0.0)
        for o in objs:
            if not o.shadow or o.kind not in ("window", "card") or o.alpha.x < 0.05:
                continue
            m = o._model
            cx, cy, cz = m[3], m[7], m[11]
            s = math.sqrt(m[0] ** 2 + m[4] ** 2 + m[8] ** 2)
            height = max(10.0, cy - floor_y - o.h * s / 2.0)
            w = o.w * s * 0.92
            depth = o.w * s * 0.26
            model = M.mul_all(M.translate(cx, floor_y + 0.8, cz), M.rot_x(-math.pi / 2))
            p.m4("uMVP", M.mul(scene.vp, model))
            p.f("uSize", w, depth)
            p.f("uSoft", 30.0 + height * 0.05)
            p.f("uOpacity", max(0.08, min(0.5, 0.58 - height / 1700.0)) * o.alpha.x * min(1.0, o.dim.x + 0.3))
            self._quad()

    # ------------------------------------------------------------ nesneler
    def draw(self, scene, obj, overlay=False):
        self.upload(obj)
        p = self.p_card
        p.use()
        if overlay:
            model = M.mul_all(M.translate(obj.pos.x, obj.pos.y, 0.0), M.scale(1.0, -1.0, 1.0), M.scale(obj.sc.x))
            mvp = M.mul(M.ortho_px(self.W, self.H), model)
            p.m4("uModel", M.ident())
            p.f("uCam", 0.0, 0.0, 1.0)
            p.f("uLight", 0.0, 0.0, 1.0)
            p.m3("uRot", [1, 0, 0, 0, 1, 0, 0, 0, 1])
            p.f("uFlat", 1.0)
        else:
            mvp = M.mul(scene.vp, obj._model)
            p.m4("uModel", obj._model)
            p.f("uCam", *scene.cam.eye)
            p.f("uLight", *self.LIGHT)
            p.m3("uRot", _rot3(obj._model))
            p.f("uFlat", 0.0)
        glow = max(0.0, obj.glow.x)
        p.m4("uMVP", mvp)
        p.f("uSize", float(obj.w), float(obj.h))
        p.f("uPad", 64.0 if glow > 0.01 else 0.0)
        p.f("uRadius", float(obj.radius))
        p.f("uAlpha", max(0.0, min(1.0, obj.alpha.x)))
        p.f("uDim", max(0.0, min(1.0, obj.dim.x)))
        p.f("uTint", *obj.tint)
        p.f("uGlass", float(obj.glass))
        p.f("uBevel", float(obj.bevel))
        p.f("uRim", float(obj.rim))
        p.f("uGlow", *[c / 255.0 for c in obj.glow_col])
        p.f("uGlowAmt", glow)
        p.f("uScreen", float(self.W), float(self.H))
        p.i("uTex", 0)
        p.i("uBlur", 1)
        self._bind_tex(1, self.ping.tex)
        self._bind_tex(0, obj.tex)
        self._quad()
