"""Nexus Shell -- Nexus OS 1 icin sifirdan yazilmis 3D masaustu kabugu."""
VERSION = "1.0"
OS_NAME = "Nexus OS 1"
