"""objects.py -- 3D uzayda yuzen nesneler: panel, kart, simge.

Her nesne bir Canvas (Pillow yuzeyi) tasir; GL tarafi bunu doku olarak 3D bir
dortgene kaplar. Fare isini nesnenin yerel z=0 duzlemiyle kesip yuzey
koordinatina (px, py) cevirerek ayni UI kodu 2D gibi calisir.
"""
import math
from . import mathx as M
from . import theme as T
from .raster import Canvas
from .spring import Spring, Spring3, SOFT
from .ui import UI

DEG = math.pi / 180.0


class Obj3D:
    def __init__(self, w, h, radius=20, kind="panel"):
        self.w, self.h, self.radius, self.kind = int(w), int(h), radius, kind
        self.canvas = Canvas(self.w, self.h)
        self.ui = UI()
        self.dirty = True
        self.mouse = None
        self.down = False
        self.hover = False
        self.visible = True
        self.parent = None
        # donusum yaylari (pozisyon: parent merkezine gore piksel, y YUKARI)
        self.pos = Spring3(0, 0, 0, **SOFT)
        self.rot = Spring3(0, 0, 0, k=170.0, c=19.0)
        self.tilt = Spring3(0, 0, 0, k=240.0, c=22.0)       # hover egimi (rx, ry)
        self.sc = Spring(1.0, k=260.0, c=21.0)
        self.alpha = Spring(1.0, k=180.0, c=24.0)
        self.glow = Spring(0.0, k=170.0, c=20.0)
        self.dim = Spring(1.0, k=120.0, c=18.0)
        self.glow_col = T.BLUE[:3]
        # gorunum
        self.glass = 1.0
        self.tint = (0.05, 0.08, 0.16, 0.50)
        self.bevel = 14.0
        self.rim = 0.7
        self.shadow = True
        self.screen_space = False
        self.tilt_deg = 2.5
        self.tex = None                  # GL doku (gl.py)
        self.gpu_dirty = True            # CPU yuzeyi degisti -> dokuyu yeniden yukle
        self.kids = []                   # cocuk nesneler (ayni sahnede, parent'a gore)
        self.no_pick = False
        self.no_tex = False              # icerigi olmayan cam levha (dock zemini)
        self.vel_tilt = False            # hizla egilme (surukleme hissi)
        self._model = M.ident()
        self._inv = None

    # ------------------------------------------------------------ donusum
    def local_matrix(self):
        return M.mul_all(M.translate(self.pos.x, self.pos.y, self.pos.z),
                         M.rot_y(self.rot.y + self.tilt.y), M.rot_x(self.rot.x + self.tilt.x),
                         M.rot_z(self.rot.z), M.scale(self.sc.x))

    def update_matrix(self):
        m = self.local_matrix()
        self._model = M.mul(self.parent._model, m) if self.parent else m
        self._inv = None
        return self._model

    @property
    def inv(self):
        if self._inv is None:
            self._inv = M.inverse(self._model)
        return self._inv

    def to_local_px(self, lx, ly):
        return lx + self.w / 2.0, self.h / 2.0 - ly

    # ------------------------------------------------------------ yasam dongusu
    def update(self, dt):
        for s in (self.pos, self.rot, self.tilt, self.sc, self.alpha, self.glow, self.dim):
            s.step(dt)
        if self.ui.step(dt):
            self.dirty = True
        if self.tick(dt):
            self.dirty = True
        if self.vel_tilt:
            vx, vy = self.pos.a[0].v, self.pos.a[1].v
            self.rot.a[1].t = max(-0.22, min(0.22, vx * 0.00035))
            self.rot.a[0].t = max(-0.15, min(0.15, -vy * 0.00025))

    def tick(self, dt):          # alt siniflar: surekli animasyon varsa True dondur
        return False

    def redraw(self):
        self.canvas.clear()
        self.ui.begin(self.canvas, self.mouse, self.down)
        self.draw(self.canvas, self.ui)
        self.dirty = False
        self.gpu_dirty = True

    def draw(self, c, ui):
        pass

    # ------------------------------------------------------------ girdi
    def mouse_move(self, px, py):
        self.mouse = (px, py)
        if not self.hover:
            self.hover = True
            self.on_enter()
        d = self.tilt_deg * DEG
        if d:
            # imlec ustteyse ust kenar geri yatar, sagdaysa sag kenar geri yatar
            self.tilt.to((py / self.h - 0.5) * 2 * d, (px / self.w - 0.5) * 2 * d, 0)
        self.dirty = True
        self.on_move(px, py)

    def mouse_leave(self):
        if self.hover or self.mouse:
            self.hover = False
            self.mouse = None
            self.tilt.to(0, 0, 0)
            self.dirty = True
            self.on_leave()

    def click(self, px, py):
        key = self.ui.hit(px, py)
        self.on_click(key, px, py)
        self.dirty = True
        return key

    def on_enter(self): pass
    def on_leave(self): pass
    def on_move(self, px, py): pass
    def on_click(self, key, px, py): pass
    def on_key(self, ch): pass
    def on_wheel(self, dy): pass
    def is_titlebar(self, px, py): return False


class Window(Obj3D):
    """Baslik cubugu + trafik isiklari olan buzlu cam panel."""
    TITLE_H = 48
    RED, YEL, GRN = (255, 95, 87, 255), (254, 188, 46, 255), (40, 200, 64, 255)

    def __init__(self, w, h, title, app_id):
        super().__init__(w, h, radius=24, kind="window")
        self.title, self.app_id = title, app_id
        self.minimized = False
        self.closing = False
        self.maxed = False
        self.focused = False
        self.tilt_deg = 1.6
        self.bevel = 18.0
        self.vel_tilt = True
        self.on_close = self.on_minimize = self.on_maximize = None

    def is_titlebar(self, px, py):
        return py < self.TITLE_H and px > 92

    def draw(self, c, ui):
        c.rrect(0, self.TITLE_H - 1, self.w, 1, 0, fill=(255, 255, 255, 22))
        for i, (key, col, glyph) in enumerate((("close", self.RED, "\u00d7"), ("min", self.YEL, "\u2212"),
                                               ("max", self.GRN, "+"))):
            cx, cy = 26 + i * 22, 24
            e, _ = ui.region(key, cx - 10, cy - 10, 20, 20)
            e = max(0.0, e)
            if e > 0.02:
                c.glow(cx - 7, cy - 7, 14, 14, 7, T.alpha(col, 170 * e), 6)
            c.circle(cx, cy, 6.5 + 1.0 * e, fill=col)
            if e > 0.1:
                c.text(cx, cy - 8, glyph, 12, (20, 20, 30, int(210 * e)), "bold", "c")
        col = T.TEXT if self.focused else T.MUTED
        c.text(self.w / 2, 15, self.title, 15, col, "bold", "c")
        self.draw_content(c, ui, 0, self.TITLE_H, self.w, self.h - self.TITLE_H)

    def draw_content(self, c, ui, x, y, w, h):
        pass

    def on_click(self, key, px, py):
        if key == "close" and self.on_close:
            self.on_close(self)
        elif key == "min" and self.on_minimize:
            self.on_minimize(self)
        elif key == "max" and self.on_maximize:
            self.on_maximize(self)
        else:
            self.on_content_click(key, px, py)

    def on_content_click(self, key, px, py):
        pass
