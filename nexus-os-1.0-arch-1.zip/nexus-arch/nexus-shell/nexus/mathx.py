"""mathx.py -- saf Python 3D matematigi (bagimlilik yok, test edilebilir).

Kurallar: sutun vektorler (v' = M v), matrisler satir-oncelikli 16 elemanli liste
(eleman [satir*4+sutun]). GL'e yuklerken transpose=GL_TRUE kullanilir.
Dunya birimi = z=0 duzleminde 1 ekran pikseli.
"""
import math

def ident():
    return [1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0]

def mul(a, b):
    r = [0.0] * 16
    for i in range(4):
        for j in range(4):
            r[i*4+j] = (a[i*4]*b[j] + a[i*4+1]*b[4+j] + a[i*4+2]*b[8+j] + a[i*4+3]*b[12+j])
    return r

def mul_all(*ms):
    out = ms[0]
    for m in ms[1:]:
        out = mul(out, m)
    return out

def translate(x, y, z):
    m = ident(); m[3], m[7], m[11] = x, y, z; return m

def scale(x, y=None, z=None):
    y = x if y is None else y; z = x if z is None else z
    m = ident(); m[0], m[5], m[10] = x, y, z; return m

def rot_x(a):
    c, s = math.cos(a), math.sin(a)
    m = ident(); m[5], m[6], m[9], m[10] = c, -s, s, c; return m

def rot_y(a):
    c, s = math.cos(a), math.sin(a)
    m = ident(); m[0], m[2], m[8], m[10] = c, s, -s, c; return m

def rot_z(a):
    c, s = math.cos(a), math.sin(a)
    m = ident(); m[0], m[1], m[4], m[5] = c, -s, s, c; return m

def perspective(fovy_deg, aspect, near, far):
    f = 1.0 / math.tan(math.radians(fovy_deg) / 2.0)
    m = [0.0] * 16
    m[0] = f / aspect; m[5] = f
    m[10] = (far + near) / (near - far); m[11] = 2.0 * far * near / (near - far)
    m[14] = -1.0
    return m

def ortho_px(w, h):
    """Ekran pikseli (sol-ust orijin, y asagi) -> klip uzayi."""
    return [2.0/w, 0, 0, -1.0, 0, -2.0/h, 0, 1.0, 0, 0, -1.0, 0, 0, 0, 0, 1.0]

def sub(a, b): return (a[0]-b[0], a[1]-b[1], a[2]-b[2])
def dot(a, b): return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def length(a): return math.sqrt(dot(a, a))
def norm(a):
    l = length(a); return (a[0]/l, a[1]/l, a[2]/l) if l else (0.0, 0.0, 0.0)

def look_at(eye, target, up=(0.0, 1.0, 0.0)):
    f = norm(sub(target, eye)); s = norm(cross(f, up)); u = cross(s, f)
    return [s[0], s[1], s[2], -dot(s, eye),
            u[0], u[1], u[2], -dot(u, eye),
            -f[0], -f[1], -f[2], dot(f, eye),
            0.0, 0.0, 0.0, 1.0]

def transform(m, v, w=1.0):
    x, y, z = v
    return (m[0]*x + m[1]*y + m[2]*z + m[3]*w, m[4]*x + m[5]*y + m[6]*z + m[7]*w,
            m[8]*x + m[9]*y + m[10]*z + m[11]*w, m[12]*x + m[13]*y + m[14]*z + m[15]*w)

def inverse(m):
    """Genel 4x4 ters (Gauss-Jordan, kismi pivot)."""
    a = [[m[r*4+c] for c in range(4)] + [1.0 if r == c else 0.0 for c in range(4)] for r in range(4)]
    for i in range(4):
        p = max(range(i, 4), key=lambda r: abs(a[r][i]))
        if abs(a[p][i]) < 1e-12:
            raise ValueError("singular matrix")
        a[i], a[p] = a[p], a[i]
        d = a[i][i]
        a[i] = [x / d for x in a[i]]
        for r in range(4):
            if r != i:
                f = a[r][i]
                if f:
                    a[r] = [x - f * y for x, y in zip(a[r], a[i])]
    return [a[r][4+c] for r in range(4) for c in range(4)]

def project(vp, p, w, h):
    """Dunya noktasi -> ekran pikseli (sol-ust orijin). (x, y, ndc_z) | None."""
    x, y, z, ww = transform(vp, p)
    if ww <= 1e-6:
        return None
    return ((x/ww*0.5 + 0.5) * w, (0.5 - y/ww*0.5) * h, z/ww)

def unproject_ray(inv_vp, cam, mx, my, w, h):
    """Ekran pikselinden dunya isini uret: (origin, dir)."""
    nx, ny = 2.0*mx/w - 1.0, 1.0 - 2.0*my/h
    x, y, z, ww = transform(inv_vp, (nx, ny, 1.0))
    far = (x/ww, y/ww, z/ww)
    return cam, norm(sub(far, cam))

def ray_to_local(model_inv, origin, direction):
    o = transform(model_inv, origin)[:3]
    d = transform(model_inv, direction, 0.0)[:3]
    return o, d

def ray_plane_z0(o, d):
    """Yerel uzayda z=0 duzlemiyle kesisim: (t, x, y) | None. t dunya-isini ile ortak parametre."""
    if abs(d[2]) < 1e-9:
        return None
    t = -o[2] / d[2]
    return t, o[0] + d[0]*t, o[1] + d[1]*t

def ray_plane_world(origin, direction, plane_z):
    if abs(direction[2]) < 1e-9:
        return None
    t = (plane_z - origin[2]) / direction[2]
    return (origin[0] + direction[0]*t, origin[1] + direction[1]*t, plane_z), t
