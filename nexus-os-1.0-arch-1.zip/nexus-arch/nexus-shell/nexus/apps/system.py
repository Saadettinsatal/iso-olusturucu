"""apps/system.py -- Sistem Izleyici (canli CPU/RAM/Disk/Ag) ve Sistem (Hakkinda + guc)."""
import time

from .. import sysinfo, theme as T
from ..objects import Window
from ..spring import Spring, SNAPPY


class MonitorWindow(Window):
    HIST = 60

    def __init__(self, w=540, h=470):
        super().__init__(w, h, "System Monitor", "monitor")
        self.info = sysinfo.SysInfo()
        self.hist = [0.0] * self.HIST
        self.disp = {k: Spring(0.0, k=90.0, c=14.0) for k in ("cpu", "mem", "disk", "net")}
        self._acc, self._peak = 1.0, 1e6
        self.info.poll()

    def tick(self, dt):
        self._acc += dt
        if self._acc >= 0.5:
            self._acc = 0.0
            self.info.poll()
            self.hist = self.hist[1:] + [self.info.cpu]
            self._peak = max(1e6, self._peak * 0.97, self.info.net_rx + self.info.net_tx)
            i = self.info
            self.disp["cpu"].t, self.disp["mem"].t, self.disp["disk"].t = i.cpu, i.mem, i.disk
            self.disp["net"].t = min(1.0, (i.net_rx + i.net_tx) / self._peak)
        busy = False
        for s in self.disp.values():
            s.step(dt)
            busy = busy or not s.at_rest(0.001)
        return busy or self._acc == 0.0

    def draw_content(self, c, ui, x, y, w, h):
        i = self.info
        c.rrect(20, y + 14, w - 40, 170, 20, fill=(255, 255, 255, 10), border=(255, 255, 255, 24))
        c.text(40, y + 26, "CPU", 12, T.MUTED, "bold")
        c.text(40, y + 44, "%d%%" % round(self.disp["cpu"].x * 100), 44, T.TEXT, "bold")
        c.text(w - 40, y + 30, "load %.2f" % i.load1, 12, T.MUTED, "mono", "r")
        c.line_chart(34, y + 100, w - 68, 76, [max(0.0, min(1.0, v)) for v in self.hist],
                     T.alpha(T.BLUE, 120), T.alpha(T.PURPLE, 8), T.BLUE)
        rows = [("Memory", self.disp["mem"].x, "%d / %d MB" % (i.mem_used_mb, i.mem_total_mb), (T.BLUE, T.PURPLE)),
                ("Disk (/)", self.disp["disk"].x, "%d%%" % round(i.disk * 100), (T.PURPLE, T.hexc("F472B6"))),
                ("Network", self.disp["net"].x, "\u2193 %s   \u2191 %s" % (sysinfo.fmt_rate(i.net_rx), sysinfo.fmt_rate(i.net_tx)),
                 (T.GOOD, T.BLUE))]
        ry = y + 204
        for name, frac, text, cols in rows:
            c.text(40, ry, name, 13, T.TEXT, "bold")
            c.text(w - 40, ry, text, 12, T.MUTED, "mono", "r")
            ui.bar(40, ry + 24, w - 80, 10, frac, cols)
            ry += 58
        c.text(40, h + 48 - 34, "uptime %s" % sysinfo.fmt_uptime(i.uptime), 12, T.DIM, "mono")
        c.text(w - 40, h + 48 - 34, "\u25cf online" if i.online else "\u25cf offline", 12,
               T.GOOD if i.online else T.WARN, "bold", "r")


class SystemWindow(Window):
    def __init__(self, shell, w=500, h=540):
        super().__init__(w, h, "System", "system")
        self.shell = shell
        self.armed = {}
        self.t_arm = 0.0

    def tick(self, dt):
        if self.armed:
            self.t_arm -= dt
            if self.t_arm <= 0:
                self.armed = {}
            return True
        return False

    def draw_content(self, c, ui, x, y, w, h):
        from .. import VERSION, OS_NAME
        c.rrect(20, y + 16, w - 40, 112, 22, grad=(T.alpha(T.BLUE, 60), T.alpha(T.PURPLE, 60)), horiz=True,
                border=(255, 255, 255, 40))
        c.text(48, y + 30, "\u25c8", 40, T.WHITE, "sym")
        c.text(100, y + 30, OS_NAME.upper(), 24, T.WHITE, "bold")
        c.text(100, y + 62, "Version %s \u00b7 Stable" % VERSION, 14, (255, 255, 255, 210))
        c.text(100, y + 86, "Arch Linux \u00b7 Nexus Shell 3D", 12, (255, 255, 255, 170))
        rows = [("OS", sysinfo.os_field("PRETTY_NAME", OS_NAME)), ("Kernel", sysinfo.kernel()),
                ("Host", sysinfo.hostname()), ("Display", "%d \u00d7 %d" % (self.shell.W, self.shell.H)),
                ("Graphics", self.shell.renderer[:42]), ("Session", "Nexus Shell \u00b7 kiosk")]
        ry = y + 146
        for k, v in rows:
            c.text(40, ry, k, 13, T.MUTED)
            c.text(w - 40, ry, v, 13, T.TEXT, "ui", "r", maxw=300)
            ry += 28
        by = h + 48 - 70
        bw = (w - 40 - 20) // 3
        for i, (key, label, kind) in enumerate((("restart_shell", "Log out", "ghost"), ("reboot", "Restart", "ghost"),
                                                  ("poweroff", "Shut down", "danger"))):
            armed = key in self.armed
            ui.button(key, 20 + i * (bw + 10), by, bw, 38, "Confirm?" if armed else label,
                      "danger" if armed else kind, True, 13)

    def on_content_click(self, key, px, py):
        if key in ("restart_shell", "reboot", "poweroff"):
            if key in self.armed:
                self.shell.system_action(key)
            else:
                self.armed = {key: True}
                self.t_arm = 3.0
