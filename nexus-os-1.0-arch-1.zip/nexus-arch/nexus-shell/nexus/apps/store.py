"""apps/store.py -- Nexus Store: kategoriler, 3D uygulama kartlari, detay karti, Install.

Her uygulama, magazanin onunde yuzen AYRI bir 3D kart nesnesidir: fareye dogru yatar,
one cikar, parlar. "Install" tiklaninca StoreBridge `nexus-store.sh install <paket>`
komutunu calistirir (bkz. bridge.py).
"""
import math
import time

from .. import theme as T
from ..bridge import RUNNING, FAIL
from ..catalog import CATEGORIES, filter_apps
from ..objects import Obj3D, Window
from ..raster import fit_text, wrap_text
from ..spring import Spring, Spring3, BOUNCY, SNAPPY

CARD_W, CARD_H, GAP = 240, 165, 16
BANNER_H = 150
CAT_GLYPH = {"Discover": "\u2726", "Utilities": "\u2699", "Games": "\u25c8",
             "Development": "\u276f", "Media": "\u266b", "Installed": "\u2713"}


def grad_of(app):
    return T.CAT_COLORS.get(app.category, T.DEFAULT_GRAD)


def size_text(app):
    return "%d MB" % app.size_mb if app.size_mb < 1000 else "%.1f GB" % (app.size_mb / 1024.0)


def app_state(bridge, app):
    job = bridge.job(app.pkg)
    if job and job.state == RUNNING:
        return "working", job
    if bridge.is_installed(app.pkg):
        return "installed", job
    if job and job.state == FAIL:
        return "failed", job
    return "none", job


def draw_actions(ui, c, store, app, x, y, w, h):
    """Duruma gore Install / Uninstall / Open / ilerleme cubugu ciz."""
    st, job = app_state(store.bridge, app)
    if st == "working":
        label = "Removing..." if job.op == "remove" else (job.status or "Installing...")
        ui.bar(x, y + 4, w, 8, job.progress)
        c.text(x, y + 18, label, 11, T.MUTED, maxw=w - 44)
        c.text(x + w, y + 18, "%d%%" % int(job.progress * 100), 11, T.BLUE, "bold", "r")
    elif st == "installed":
        if app.exec:
            ow = int(w * 0.42)
            ui.button("open", x, y, ow, h, "Open", "ok")
            ui.button("remove", x + ow + 10, y, w - ow - 10, h, "Uninstall", "danger")
        else:
            ui.button("remove", x, y, w, h, "Uninstall", "danger")
    else:
        ui.button("install", x, y, w, h, "Retry" if st == "failed" else "Install", "primary")


def do_action(store, app, key):
    if key == "install":
        if not store.bridge.install(app.pkg):
            store.toast("Another operation is still running")
    elif key == "remove":
        if not store.bridge.remove(app.pkg):
            store.toast("Another operation is still running")
    elif key == "open":
        store.toast("Launching %s..." % app.name)
        store.bridge.launch(app.exec)


def _signature(store, app):
    st, job = app_state(store.bridge, app)
    return (st, int(job.progress * 100) if job else 0, job.status if job else "")


# ============================================================================ kart
class AppCard(Obj3D):
    def __init__(self, store, index):
        super().__init__(CARD_W, CARD_H, radius=22, kind="card")
        self.store, self.index, self.app = store, index, None
        self.pos = Spring3(0, 0, 0, **BOUNCY)
        self.tilt_deg, self.bevel, self.rim = 8.0, 12.0, 0.9
        self.tint = (0.07, 0.10, 0.21, 0.62)
        self.base = (0.0, 0.0, 26.0)
        self.pending = 0.0
        self._sig = None
        self.visible = False

    def set_app(self, app, base, delay, animate=True):
        self.app, self.base = app, base
        self.visible = app is not None
        if not app:
            return
        self.glow_col = grad_of(app)[0][:3]
        self.pending = delay if animate else 0.0
        if animate:
            self.pos.set(base[0], base[1], base[2] - 90)
            self.rot.set(0.0, -1.15, 0.0)
            self.alpha.set(0.0)
            self.sc.set(0.88)
            if delay <= 0:
                self._enter()
        else:
            self.pos.set(*base)
            self.rot.set(0, 0, 0)
            self.alpha.set(1.0)
            self.sc.set(1.0)
        self._sig = None
        self.dirty = True

    def _enter(self):
        self.pos.to(*self.base)
        self.rot.to(0, 0, 0)
        self.alpha.t = 1.0
        self.sc.t = 1.0

    def tick(self, dt):
        if not self.app:
            return False
        if self.pending > 0:
            self.pending -= dt
            if self.pending <= 0:
                self._enter()
            return False
        sig = _signature(self.store, self.app)
        changed, self._sig = sig != self._sig, sig
        return changed or sig[0] == "working"

    def on_enter(self):
        self.glow.t = 0.9
        self.pos.a[2].t = self.base[2] + 52
        self.sc.t = 1.07

    def on_leave(self):
        self.glow.t = 0.0
        self.pos.a[2].t = self.base[2]
        self.sc.t = 1.0

    def draw(self, c, ui):
        a = self.app
        if not a:
            return
        st, job = app_state(self.store.bridge, a)
        ui.tile(16, 16, 56, a.glyph, grad_of(a))
        c.text(84, 14, a.name, 17, T.TEXT, "bold", maxw=CARD_W - 100)
        c.text(84, 38, "%s \u00b7 %s" % (a.category, size_text(a)), 12, T.MUTED, maxw=CARD_W - 100)
        n = ui.stars(84, 58, a.rating, 13)
        c.text(84 + n + 6, 58, "%.1f" % a.rating, 12, T.MUTED)
        if st == "failed" and job:
            for i, ln in enumerate(wrap_text(job.error or "Failed", 11, CARD_W - 32, max_lines=2)):
                c.text(16, 88 + i * 15, ln, 11, T.BAD)
        else:
            c.text(16, 90, a.tagline, 13, (203, 213, 225, 235), maxw=CARD_W - 32)
        draw_actions(ui, c, self.store, a, 16, CARD_H - 50, CARD_W - 32, 34)

    def on_click(self, key, px, py):
        if key in ("install", "remove", "open"):
            do_action(self.store, self.app, key)
        elif key is None and self.app:
            self.store.show_detail(self.app)


# ==================================================================== one cikan banner
class FeaturedCard(Obj3D):
    def __init__(self, store):
        super().__init__(CARD_W * 3 + GAP * 2, BANNER_H, radius=26, kind="card")
        self.store, self.app, self.feats, self.i, self.timer = store, None, [], 0, 0.0
        self.pos = Spring3(0, 0, 0, **BOUNCY)
        self.tilt_deg, self.bevel, self.rim = 3.5, 16.0, 1.0
        self.base = (0.0, 0.0, 30.0)
        self._sig = None
        self.visible = False

    def set_feats(self, feats, base, animate=True):
        self.feats, self.base = feats, base
        self.visible = bool(feats)
        if feats:
            self.i %= len(feats)
            self._show(animate)

    def _show(self, flip):
        self.app = self.feats[self.i]
        self.glow_col = grad_of(self.app)[0][:3]
        self.timer = 0.0
        self.pos.set(*self.base)
        if flip:
            self.rot.set(-0.9, 0.0, 0.0)
            self.rot.to(0, 0, 0)
            self.alpha.set(0.2)
            self.alpha.t = 1.0
        self._sig = None
        self.dirty = True

    def tick(self, dt):
        if not self.app:
            return False
        self.timer += dt
        if self.timer > 7.0 and len(self.feats) > 1 and not self.hover and not self.store.detail.visible:
            self.i = (self.i + 1) % len(self.feats)
            self._show(True)
        sig = _signature(self.store, self.app) + (self.i,)
        changed, self._sig = sig != self._sig, sig
        return changed or sig[0] == "working"

    def on_enter(self):
        self.glow.t = 0.8
        self.pos.a[2].t = self.base[2] + 28

    def on_leave(self):
        self.glow.t = 0.0
        self.pos.a[2].t = self.base[2]

    def draw(self, c, ui):
        a = self.app
        if not a:
            return
        g = grad_of(a)
        w, h = self.w, self.h
        c.rrect(0, 0, w, h, 26, grad=(T.alpha(g[0], 215), T.alpha(g[1], 215)), horiz=True)
        c.circle(w - 90, h / 2 + 10, 120, fill=(255, 255, 255, 18))
        c.circle(w - 40, 20, 70, fill=(255, 255, 255, 14))
        c.text(w - 170, h / 2 - 78, a.glyph, 130, (255, 255, 255, 80), "sym")
        c.rrect(24, 14, 96, 24, 12, fill=(0, 0, 0, 70))
        c.text(72, 18, "FEATURED", 11, (255, 255, 255, 240), "bold", "c")
        c.text(24, 40, a.name, 30, (255, 255, 255, 255), "bold", maxw=w - 300)
        c.text(24, 80, a.tagline, 14, (255, 255, 255, 225), maxw=w - 300)
        draw_actions(ui, c, self.store, a, 24, h - 46, 250, 34)
        for k in range(len(self.feats)):
            c.circle(w - 40 - (len(self.feats) - 1 - k) * 14, h - 20, 3.5 if k != self.i else 5,
                     fill=(255, 255, 255, 255 if k == self.i else 100))

    def on_click(self, key, px, py):
        if key in ("install", "remove", "open"):
            do_action(self.store, self.app, key)
        elif key is None and self.app:
            self.store.show_detail(self.app)


# ======================================================================== detay karti
class DetailCard(Obj3D):
    W, H = 620, 400

    def __init__(self, store):
        super().__init__(self.W, self.H, radius=28, kind="card")
        self.store, self.app = store, None
        self.pos = Spring3(0, 0, 0, **BOUNCY)
        self.tilt_deg, self.bevel, self.rim = 3.0, 18.0, 1.0
        self.tint = (0.06, 0.09, 0.19, 0.78)
        self.visible = False
        self._sig = None

    def show(self, app):
        self.app, self.visible = app, True
        self.glow_col = grad_of(app)[0][:3]
        self.pos.set(0, -30, 40)
        self.pos.to(0, -8, 150)
        self.rot.set(0.45, 0.0, 0.0)
        self.rot.to(0, 0, 0)
        self.sc.set(0.82)
        self.sc.t = 1.0
        self.alpha.set(0.0)
        self.alpha.t = 1.0
        self.glow.t = 0.9
        self._sig = None
        self.dirty = True

    def hide(self):
        self.app = None
        self.visible = False

    def tick(self, dt):
        if not self.app:
            return False
        sig = _signature(self.store, self.app)
        changed, self._sig = sig != self._sig, sig
        return changed or sig[0] == "working"

    def draw(self, c, ui):
        a = self.app
        if not a:
            return
        st, job = app_state(self.store.bridge, a)
        ui.tile(28, 28, 96, a.glyph, grad_of(a))
        c.text(144, 24, a.name, 30, T.TEXT, "bold", maxw=self.W - 220)
        c.text(144, 64, a.tagline, 15, T.MUTED, maxw=self.W - 220)
        n = ui.stars(144, 94, a.rating, 17)
        c.text(144 + n + 8, 95, "%.1f / 5" % a.rating, 14, T.TEXT)
        for i, (k, v) in enumerate((("Category", a.category), ("Size", size_text(a)), ("Package", a.pkg))):
            x = 144 + i * 150
            c.text(x, 128, k.upper(), 10, T.DIM, "bold")
            c.text(x, 144, v, 14, T.TEXT, "bold", maxw=140)
        c.rrect(28, 176, self.W - 56, 1, 0, fill=(255, 255, 255, 24))
        for i, ln in enumerate(wrap_text(a.description, 14, self.W - 56, max_lines=4)):
            c.text(28, 192 + i * 22, ln, 14, (203, 213, 225, 240))
        if st == "failed" and job:
            c.text(28, 288, "Last attempt failed: " + fit_text(job.error, 12, self.W - 220), 12, T.BAD)
        draw_actions(ui, c, self.store, a, 28, self.H - 70, 300, 42)
        e, _ = ui.region("close", self.W - 58, 18, 40, 40)
        c.circle(self.W - 38, 38, 15 + 2 * max(0, e), fill=(255, 255, 255, int(20 + 40 * max(0, e))))
        c.text(self.W - 38, 28, "\u00d7", 20, T.TEXT, "bold", "c")

    def on_click(self, key, px, py):
        if key == "close":
            self.store.hide_detail()
        elif key in ("install", "remove", "open"):
            do_action(self.store, self.app, key)


# ===================================================================== magaza penceresi
class StoreWindow(Window):
    SB = 196

    def __init__(self, w, h, bridge, apps):
        super().__init__(w, h, "Nexus Store", "store")
        self.bridge, self.all_apps = bridge, apps
        self.cat, self.page, self.query, self.search_focus = 0, 0, "", False
        self.pill = Spring(0.0, **SNAPPY)
        self.cards = [AppCard(self, i) for i in range(6)]
        self.banner = FeaturedCard(self)
        self.detail = DetailCard(self)
        self.kids = self.cards + [self.banner, self.detail]
        self.toast_text, self.toast_t, self._blink = "", 0.0, 0.0
        self._inst_sig = None
        self.main_w = CARD_W * 3 + GAP * 2
        self.main_x = w - 28 - self.main_w
        self.layout(animate=True)

    # ---------------------------------------------------------------- yerlesim
    def apps_now(self):
        return filter_apps(self.all_apps, CATEGORIES[self.cat], self.query, installed=set(self.bridge.installed))

    def banner_mode(self):
        return self.cat == 0 and not self.query and any(a.featured for a in self.all_apps)

    def per_page(self):
        return 3 if self.banner_mode() else 6

    def pages(self):
        return max(1, math.ceil(len(self.apps_now()) / self.per_page()))

    def layout(self, animate=True):
        apps = self.apps_now()
        pp = self.per_page()
        self.page = max(0, min(self.page, self.pages() - 1))
        chunk = apps[self.page * pp:(self.page + 1) * pp]
        y0 = 122
        if self.banner_mode():
            feats = [a for a in self.all_apps if a.featured]
            self.banner.set_feats(feats, self._local(self.main_x + self.main_w / 2, y0 + BANNER_H / 2, 30), animate)
            y0 += BANNER_H + GAP
        else:
            self.banner.visible = False
        for i, card in enumerate(self.cards):
            if i < len(chunk):
                col, row = i % 3, i // 3
                cx = self.main_x + col * (CARD_W + GAP) + CARD_W / 2
                cy = y0 + row * (CARD_H + GAP) + CARD_H / 2
                card.set_app(chunk[i], self._local(cx, cy, 26), 0.05 * i + (0.06 if animate else 0), animate)
            else:
                card.set_app(None, (0, 0, 0), 0)
        self.dirty = True

    def _local(self, cx, cy, z):
        return (cx - self.w / 2.0, self.h / 2.0 - cy, z)

    # ---------------------------------------------------------------- detay / bildirim
    def show_detail(self, app):
        self.detail.show(app)
        for k in self.cards + [self.banner]:
            k.dim.t, k.no_pick = 0.4, True
        self.dim.t = 0.65

    def hide_detail(self):
        self.detail.hide()
        for k in self.cards + [self.banner]:
            k.dim.t, k.no_pick = 1.0, False
        self.dim.t = 1.0

    def toast(self, msg):
        self.toast_text, self.toast_t, self.dirty = msg, 3.0, True

    # ---------------------------------------------------------------- yasam dongusu
    def tick(self, dt):
        dirty = False
        if self.toast_t > 0:
            self.toast_t -= dt
            dirty = True
        if self.search_focus:
            self._blink += dt
            dirty = dirty or int(self._blink * 2) != int((self._blink - dt) * 2)
        self.pill.t = 76 + self.cat * 46
        self.pill.step(dt)
        if not self.pill.at_rest():
            dirty = True
        sig = frozenset(self.bridge.installed)
        if sig != self._inst_sig:
            first, self._inst_sig = self._inst_sig is None, sig
            if not first and CATEGORIES[self.cat] == "Installed":
                self.layout(animate=False)
            dirty = True
        return dirty

    def on_key(self, ch):
        if not self.search_focus:
            return
        if ch == "BACKSPACE":
            self.query = self.query[:-1]
        elif ch == "ESC":
            self.query, self.search_focus = "", False
        elif ch == "ENTER":
            self.search_focus = False
        elif len(ch) == 1 and ch.isprintable() and len(self.query) < 28:
            self.query += ch
        self.page = 0
        self.layout(animate=True)

    def on_wheel(self, dy):
        if self.pages() > 1:
            self.go_page(self.page - (1 if dy > 0 else -1))

    def go_page(self, p):
        p = max(0, min(self.pages() - 1, p))
        if p != self.page:
            self.page = p
            self.layout(animate=True)

    # ---------------------------------------------------------------- cizim
    def draw_content(self, c, ui, x, y, w, h):
        SB = self.SB
        c.rrect(14, 62, SB - 14, self.h - 76, 20, fill=(255, 255, 255, 10), border=(255, 255, 255, 22))
        c.rrect(22, self.pill.x, SB - 30, 38, 14, grad=(T.alpha(T.BLUE, 70), T.alpha(T.PURPLE, 70)), horiz=True,
                border=(255, 255, 255, 40))
        for i, name in enumerate(CATEGORIES):
            by = 76 + i * 46
            e, _ = ui.region("cat:%d" % i, 22, by, SB - 30, 38)
            e = max(0.0, e)
            sel = i == self.cat
            c.text(40, by + 9, CAT_GLYPH[name], 16, T.BLUE if sel else T.MUTED, "sym")
            c.text(70 + 2 * e, by + 9, name, 15, T.TEXT if sel else T.MUTED, "bold" if sel else "ui")
        if self.bridge.online is False:
            c.text(34, self.h - 44, "\u25cf Offline", 12, T.WARN, "bold")
        elif self.bridge.online:
            c.text(34, self.h - 44, "\u25cf Online", 12, T.GOOD, "bold")
        else:
            c.text(34, self.h - 44, "\u25cf Syncing...", 12, T.MUTED, "bold")
        # baslik + arama
        apps = self.apps_now()
        c.text(self.SB + 28, 64, CATEGORIES[self.cat], 26, T.TEXT, "bold")
        c.text(self.SB + 30, 96, "%d app%s" % (len(apps), "" if len(apps) == 1 else "s"), 12, T.MUTED)
        sw = 270
        sx = self.w - 28 - sw
        e, _ = ui.region("search", sx, 62, sw, 38)
        e = max(0.0, e)
        c.rrect(sx, 62, sw, 38, 19, fill=(255, 255, 255, int(16 + 14 * e + (16 if self.search_focus else 0))),
                border=T.alpha(T.BLUE if self.search_focus else T.WHITE, 150 if self.search_focus else 40))
        c.text(sx + 16, 71, "\u25cb", 14, T.MUTED, "sym")
        if self.query or self.search_focus:
            caret = "|" if self.search_focus and int(self._blink * 2) % 2 == 0 else ""
            c.text(sx + 38, 70, self.query + caret, 15, T.TEXT, maxw=sw - 54)
        else:
            c.text(sx + 38, 70, "Search apps...", 15, T.DIM)
        if not apps:
            c.text(self.SB + self.main_w / 2 + 28, 280, "Nothing here yet", 20, T.MUTED, "bold", "c")
        # sayfalama
        n = self.pages()
        if n > 1:
            py = self.h - 52
            cx = self.main_x + self.main_w / 2
            ui.button("prev", cx - 110, py, 40, 32, "\u25c0", "ghost", self.page > 0, 14)
            ui.button("next", cx + 70, py, 40, 32, "\u25b6", "ghost", self.page < n - 1, 14)
            for k in range(n):
                c.circle(cx - (n - 1) * 8 + k * 16, py + 16, 4.5 if k == self.page else 3,
                         fill=T.alpha(T.BLUE if k == self.page else T.WHITE, 255 if k == self.page else 80))
        if self.toast_t > 0 and self.toast_text:
            a = int(255 * min(1.0, self.toast_t))
            tw = len(self.toast_text) * 7 + 36
            c.rrect(self.w / 2 + 60 - tw / 2, self.h - 96, tw, 32, 16, fill=(10, 16, 32, int(a * 0.85)),
                    border=T.alpha(T.BLUE, int(a * 0.6)))
            c.text(self.w / 2 + 60, self.h - 88, self.toast_text, 13, T.alpha(T.TEXT, a), "ui", "c")

    def on_content_click(self, key, px, py):
        if self.detail.visible and key is None:
            self.hide_detail()
            return
        if key and key.startswith("cat:"):
            i = int(key[4:])
            if i != self.cat:
                self.cat, self.page = i, 0
                self.hide_detail()
                self.layout(animate=True)
            self.search_focus = False
        elif key == "search":
            self.search_focus, self._blink = True, 0.0
        elif key == "prev":
            self.go_page(self.page - 1)
        elif key == "next":
            self.go_page(self.page + 1)
        else:
            self.search_focus = False
