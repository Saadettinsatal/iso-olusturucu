"""bridge.py -- Nexus Store koprusu.

"Install" tiklaninca TAM OLARAK su komut calisir:

    nexus-store.sh install <paket_adi>

Cikti satir satir okunur, pacman ilerlemesi ayristirilip arayuze beslenir.
Betik yoksa (gelistirme makinesi) ya da NEXUS_SIM=1 ise simulasyon modu devreye girer.
"""
import os
import re
import shutil
import subprocess
import threading
import time

OK, FAIL, RUNNING, IDLE = "ok", "fail", "running", "idle"


class Job:
    def __init__(self, pkg, op):
        self.pkg, self.op = pkg, op
        self.state = RUNNING
        self.progress = 0.02
        self.status = "Starting..."
        self.error = ""
        self.rc = None


_RE_STEP = re.compile(r"^\((\d+)/(\d+)\)\s+(.*)$")
_RE_PKGS = re.compile(r"^Packages \((\d+)\)")


class StoreBridge:
    def __init__(self, cmd=None, sim=None):
        self.cmd = cmd or os.environ.get("NEXUS_STORE_CMD") or "nexus-store.sh"
        if sim is None:
            sim = os.environ.get("NEXUS_SIM") == "1" or shutil.which(self.cmd) is None
        self.sim = sim
        self.jobs = {}
        self.installed = set()
        self.online = None            # None = bilinmiyor
        self.busy = False
        self._lock = threading.Lock()

    # ------------------------------------------------------------ sorgu
    def refresh(self):
        if self.sim:
            return
        try:
            out = subprocess.run([self.cmd, "list-installed"], capture_output=True, text=True, timeout=20).stdout
            with self._lock:
                self.installed = {l.strip() for l in out.splitlines() if l.strip()}
        except (OSError, subprocess.SubprocessError):
            pass

    def is_installed(self, pkg):
        with self._lock:
            return pkg in self.installed

    def job(self, pkg):
        return self.jobs.get(pkg)

    # ------------------------------------------------------------ islemler
    def sync_async(self):
        def run():
            if self.sim:
                time.sleep(0.8)
                self.online = True
                return
            try:
                self.online = subprocess.run([self.cmd, "check-online"], capture_output=True, timeout=15).returncode == 0
            except (OSError, subprocess.SubprocessError):
                self.online = False
        threading.Thread(target=run, daemon=True).start()

    def install(self, pkg):
        return self._start(pkg, "install")

    def remove(self, pkg):
        return self._start(pkg, "remove")

    def _start(self, pkg, op):
        with self._lock:
            if self.busy:
                return False
            self.busy = True
        job = Job(pkg, op)
        self.jobs[pkg] = job
        threading.Thread(target=self._run, args=(job,), daemon=True).start()
        return True

    def _finish(self, job, ok, err=""):
        job.state = OK if ok else FAIL
        job.error = err
        if ok:
            job.progress = 1.0
            job.status = "Done"
            with self._lock:
                (self.installed.add if job.op == "install" else self.installed.discard)(job.pkg)
        else:
            job.status = err or "Failed"
        self.busy = False

    def _run(self, job):
        if self.sim:
            return self._simulate(job)
        argv = [self.cmd, job.op, job.pkg]               # <-- tam komut: nexus-store.sh install <paket>
        try:
            p = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        except OSError as e:
            return self._finish(job, False, "cannot run %s: %s" % (self.cmd, e))
        first_err, last, total, dl = "", "", 0, 0
        for line in p.stdout:
            line = line.rstrip()
            if not line:
                continue
            m = _RE_PKGS.match(line)
            if m:
                total = int(m.group(1))
            low = line.lower()
            prog = job.progress
            if "downloading" in low or "retrieving" in low:
                dl += 1
                prog = 0.06 + 0.42 * min(1.0, dl / max(1, total + 1))
                job.status = "Downloading..."
            elif low.startswith("(") and ("checking" in low or "loading" in low):
                prog = max(prog, 0.50)
                job.status = "Verifying..."
            else:
                m = _RE_STEP.match(line)
                if m and ("installing" in low or "upgrading" in low or "removing" in low):
                    n, t = int(m.group(1)), int(m.group(2))
                    prog = 0.55 + 0.42 * n / max(1, t)
                    job.status = m.group(3)[:56]
                elif "post-transaction" in low:
                    prog = max(prog, 0.98)
                    job.status = "Finishing..."
                elif low.startswith("error") and not first_err:
                    first_err = line[:110]
            job.progress = max(job.progress, min(prog, 0.99))
            last = line
        rc = p.wait()
        job.rc = rc
        if rc == 0:
            self._finish(job, True)
        else:
            self._finish(job, False, first_err or last[:110] or "failed (exit %d)" % rc)

    def _simulate(self, job):
        for i in range(1, 41):
            time.sleep(0.06)
            job.progress = i / 41.0
            job.status = "Downloading..." if i < 14 else ("Installing..." if job.op == "install" else "Removing...")
        self._finish(job, True)

    # ------------------------------------------------------------ calistir
    def launch(self, command):
        """Kurulu uygulamayi bagimsiz bir surec olarak baslat (kabuktan ayrik)."""
        if not command:
            return False
        try:
            p = subprocess.Popen(["sh", "-c", command], start_new_session=True,
                                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            threading.Thread(target=p.wait, daemon=True).start()      # zombi birakma
            return True
        except OSError:
            return False
