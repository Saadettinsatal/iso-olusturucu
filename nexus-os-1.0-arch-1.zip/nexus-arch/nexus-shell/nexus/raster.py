"""raster.py -- Pillow ile anti-aliasli UI rasterlestirme (panel/kart icerikleri).

Her 3D nesnenin yuzeyi bir Canvas'tir; GL tarafi bunu doku olarak yukler.
Sekiller 4x supersampling maskeleriyle cizilir ve onbellege alinir.
"""
import os
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

_FONT_DIRS = ["/usr/share/fonts", "/usr/local/share/fonts", os.path.expanduser("~/.fonts"),
              os.path.expanduser("~/.local/share/fonts")]
_PREF = {
    "ui":   ["Inter-Regular.otf", "InterVariable.ttf", "Inter[opsz,wght].ttf", "NotoSans-Regular.ttf", "DejaVuSans.ttf"],
    "bold": ["Inter-Bold.otf", "NotoSans-Bold.ttf", "DejaVuSans-Bold.ttf"],
    "mono": ["JetBrainsMono-Regular.ttf", "DejaVuSansMono.ttf"],
    "sym":  ["DejaVuSans.ttf"],
}
_index = None

def _scan():
    global _index
    if _index is None:
        _index = {}
        for root in _FONT_DIRS:
            for dp, _, files in os.walk(root):
                for f in files:
                    _index.setdefault(f, os.path.join(dp, f))
    return _index

@lru_cache(maxsize=64)
def font(kind, size):
    idx = _scan()
    for name in _PREF.get(kind, _PREF["ui"]):
        if name in idx:
            try:
                return ImageFont.truetype(idx[name], size)
            except OSError:
                continue
    return ImageFont.load_default()

# ----------------------------------------------------------------- onbellekli parcalar
@lru_cache(maxsize=1024)
def _mask(w, h, r, ss=4):
    r = max(0, min(r, w // 2, h // 2))
    big = Image.new("L", (w * ss, h * ss), 0)
    ImageDraw.Draw(big).rounded_rectangle((0, 0, w * ss - 1, h * ss - 1), radius=r * ss, fill=255)
    return big.resize((w, h), Image.LANCZOS)

@lru_cache(maxsize=256)
def _ring(w, h, r, bw):
    outer = _mask(w, h, r)
    inner = Image.new("L", (w, h), 0)
    if w > 2 * bw and h > 2 * bw:
        inner.paste(_mask(w - 2 * bw, h - 2 * bw, max(0, r - bw)), (bw, bw))
    return ImageChops.subtract(outer, inner)

@lru_cache(maxsize=256)
def _vgrad(w, h, top, bot):
    col = Image.new("RGBA", (1, h))
    for y in range(h):
        t = y / max(1, h - 1)
        col.putpixel((0, y), tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(4)))
    return col.resize((w, h), Image.NEAREST)

@lru_cache(maxsize=96)
def _hgrad(w, h, left, right):
    col = Image.new("RGBA", (w, 1))
    for x in range(w):
        t = x / max(1, w - 1)
        col.putpixel((x, 0), tuple(int(left[i] + (right[i] - left[i]) * t) for i in range(4)))
    return col.resize((w, h), Image.NEAREST)

@lru_cache(maxsize=2048)
def _text(s, kind, size, color):
    f = font(kind, size)
    asc, desc = f.getmetrics()
    w = int(f.getlength(s)) + 3
    h = asc + desc + 2
    mask = Image.new("L", (max(1, w), h), 0)
    ImageDraw.Draw(mask).text((0, 0), s, font=f, fill=255)
    if color[3] != 255:
        mask = mask.point(lambda v, a=color[3]: v * a // 255)
    sp = Image.new("RGBA", mask.size, color[:3] + (0,))
    sp.putalpha(mask)
    return sp

@lru_cache(maxsize=128)
def _glow(w, h, r, color, blur):
    pad = blur * 3
    im = Image.new("RGBA", (w + 2 * pad, h + 2 * pad), color[:3] + (0,))
    m = Image.new("L", im.size, 0)
    m.paste(_mask(w, h, r), (pad, pad))
    m = m.filter(ImageFilter.GaussianBlur(blur)).point(lambda v, a=color[3]: v * a // 255)
    im.putalpha(m)
    return im, pad

def text_width(s, size, kind="ui"):
    return font(kind, size).getlength(s)

def fit_text(s, size, maxw, kind="ui"):
    if text_width(s, size, kind) <= maxw:
        return s
    while s and text_width(s + "\u2026", size, kind) > maxw:
        s = s[:-1]
    return s.rstrip() + "\u2026"

def wrap_text(s, size, maxw, kind="ui", max_lines=99):
    lines, cur = [], ""
    for word in s.split():
        t = (cur + " " + word).strip()
        if text_width(t, size, kind) <= maxw or not cur:
            cur = t
        else:
            lines.append(cur); cur = word
    if cur: lines.append(cur)
    if len(lines) > max_lines:
        lines = lines[:max_lines]; lines[-1] = fit_text(lines[-1] + " \u2026", size, maxw, kind)
    return lines

# ------------------------------------------------------------------------- Canvas
class Canvas:
    def __init__(self, w, h):
        self.w, self.h = int(w), int(h)
        self.img = Image.new("RGBA", (self.w, self.h), (0, 0, 0, 0))

    def clear(self):
        self.img.paste((0, 0, 0, 0), (0, 0, self.w, self.h))

    def blit(self, sp, x, y):
        x, y = int(round(x)), int(round(y)); w, h = sp.size
        x0, y0, x1, y1 = max(x, 0), max(y, 0), min(x + w, self.w), min(y + h, self.h)
        if x1 <= x0 or y1 <= y0:
            return
        if (x0, y0, x1, y1) != (x, y, x + w, y + h):
            sp = sp.crop((x0 - x, y0 - y, x1 - x, y1 - y))
        self.img.alpha_composite(sp, (x0, y0))

    def rrect(self, x, y, w, h, r, fill=None, grad=None, border=None, bw=1, horiz=False):
        w, h = int(round(w)), int(round(h))
        if w < 1 or h < 1:
            return
        m = _mask(w, h, int(r))
        if grad:
            sp = (_hgrad if horiz else _vgrad)(w, h, tuple(grad[0]), tuple(grad[1])).copy()
            sp.putalpha(ImageChops.multiply(sp.getchannel("A"), m))
            self.blit(sp, x, y)
        elif fill:
            a = fill[3]
            sp = Image.new("RGBA", (w, h), fill[:3] + (0,))
            sp.putalpha(m if a == 255 else m.point(lambda v, a=a: v * a // 255))
            self.blit(sp, x, y)
        if border:
            ring = _ring(w, h, int(r), bw)
            a = border[3]
            sp = Image.new("RGBA", (w, h), border[:3] + (0,))
            sp.putalpha(ring if a == 255 else ring.point(lambda v, a=a: v * a // 255))
            self.blit(sp, x, y)

    def circle(self, cx, cy, rad, **kw):
        d = int(round(rad * 2)); self.rrect(cx - rad, cy - rad, d, d, rad, **kw)

    def glow(self, x, y, w, h, r, color, blur=10):
        sp, pad = _glow(int(w), int(h), int(r), tuple(color), int(blur))
        self.blit(sp, x - pad, y - pad)

    def text(self, x, y, s, size, color, kind="ui", anchor="l", maxw=None):
        if maxw is not None:
            s = fit_text(s, size, maxw, kind)
        sp = _text(s, kind, int(size), tuple(color))
        w = sp.size[0] - 3
        if anchor == "c": x -= w / 2
        elif anchor == "r": x -= w
        self.blit(sp, x, y)
        return w

    def line_chart(self, x, y, w, h, values, top, bottom, line, ss=3):
        """Alan grafigi (0..1 degerler), anti-aliasli."""
        n = len(values)
        if n < 2:
            return
        big = Image.new("L", (w * ss, h * ss), 0)
        pts = [(i / (n - 1) * (w * ss - 1), (h - 2 - values[i] * (h - 6)) * ss) for i in range(n)]
        d = ImageDraw.Draw(big)
        d.polygon(pts + [(w * ss - 1, h * ss), (0, h * ss)], fill=255)
        area = big.resize((w, h), Image.LANCZOS)
        sp = _vgrad(w, h, tuple(top), tuple(bottom)).copy()
        sp.putalpha(ImageChops.multiply(sp.getchannel("A"), area))
        self.blit(sp, x, y)
        ln = Image.new("L", (w * ss, h * ss), 0)
        ImageDraw.Draw(ln).line(pts, fill=255, width=2 * ss, joint="curve")
        ln = ln.resize((w, h), Image.LANCZOS)
        s2 = Image.new("RGBA", (w, h), tuple(line[:3]) + (0,)); s2.putalpha(ln)
        self.blit(s2, x, y)
