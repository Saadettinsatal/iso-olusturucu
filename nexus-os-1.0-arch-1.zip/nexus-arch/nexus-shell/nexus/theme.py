"""theme.py -- Nexus renk paleti ve olculer (koyu mod, cam efekti)."""

def hexc(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

def alpha(c, a):
    return (c[0], c[1], c[2], int(max(0, min(255, a))))

def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(4))

NAVY    = hexc("0F172A")
SLATE   = hexc("1E293B")
BLUE    = hexc("38BDF8")      # neon mavi
PURPLE  = hexc("A855F7")      # neon mor
TEXT    = hexc("E2E8F0")
MUTED   = hexc("94A3B8")
DIM     = hexc("64748B")
GOOD    = hexc("34D399")
WARN    = hexc("FBBF24")
BAD     = hexc("F87171")
WHITE   = (255, 255, 255, 255)

CAT_COLORS = {            # kategori -> (ust, alt) gradyan
    "Utilities":   (hexc("38BDF8"), hexc("6366F1")),
    "Games":       (hexc("F472B6"), hexc("A855F7")),
    "Development": (hexc("34D399"), hexc("0EA5E9")),
    "Media":       (hexc("FB923C"), hexc("EC4899")),
}
DEFAULT_GRAD = (BLUE, PURPLE)
