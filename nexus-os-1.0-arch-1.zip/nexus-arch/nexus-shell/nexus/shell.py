"""shell.py -- Nexus Shell: pencere yonetimi, girdi, dock ve ana dongu.

`Shell` sinifi GL'den bagimsizdir (test edilebilir); `run()` pygame penceresi +
OpenGL baglami acip her kare Shell.update() / Shell.render() cagirir.
"""
import os
import sys
import time

from . import catalog, sysinfo, theme as T
from .apps.store import StoreWindow
from .apps.system import MonitorWindow, SystemWindow
from .bridge import StoreBridge
from .dock import Dock, TopBar, DockIcon
from .objects import Window
from .scene import Scene

A1 = tuple(c / 255.0 for c in T.BLUE[:3])
A2 = tuple(c / 255.0 for c in T.PURPLE[:3])


class Shell:
    def __init__(self, W, H, gfx=None, bridge=None, apps=None):
        self.W, self.H = int(W), int(H)
        self.gfx = gfx
        self.renderer = gfx.renderer if gfx else "headless"
        self.scene = Scene(self.W, self.H)
        self.bridge = bridge or StoreBridge()
        self.apps = apps if apps is not None else catalog.load()
        self.bridge.refresh()
        self.bridge.sync_async()
        self.windows = {}
        self.focused = None
        self.mouse = None
        self.hover = None
        self.drag = None
        self.pressed = None
        self.objs = []
        self.exit_requested = False
        self._inst_sig = None
        self._net_t, self._net_ok = 0.0, True
        self.topbar = TopBar(self, self.W)
        self.topbar.pos.set(self.W / 2.0, 28.0, 0.0)
        self.scene.overlay.append(self.topbar)
        self.dock = Dock(self.scene, self)
        self.build_dock()
        self.open_window("store")

    # ------------------------------------------------------------------ pencereler
    def _make(self, app_id):
        W, H = self.W, self.H
        if app_id == "store":
            w = StoreWindow(min(1000, W - 60), min(640, H - 200), self.bridge, self.apps)
            home = (0.0, 18.0)
        elif app_id == "monitor":
            w = MonitorWindow(min(540, W - 60), min(470, H - 200))
            home = (-W * 0.27, 34.0)
        else:
            w = SystemWindow(self, min(500, W - 60), min(540, H - 190))
            home = (W * 0.26, -16.0)
        w.home = home
        w.on_close, w.on_minimize, w.on_maximize = self.close_window, self.minimize_window, self.toggle_max
        return w

    def open_window(self, app_id):
        win = self.windows.get(app_id)
        if win is None:
            win = self.windows[app_id] = self._make(app_id)
            self.scene.add(win)
            win.pos.set(win.home[0], win.home[1] - 70, -260.0)
            win.alpha.set(0.0)
            win.sc.set(0.86)
            win.rot.set(0.35, 0.0, 0.0)
            win.visible = True
        elif win.minimized:
            win.minimized = False
            win.visible = True
        win.closing = False
        win.alpha.t = 1.0
        win.sc.t = 1.0
        win.rot.to(0, 0, 0)
        win.pos.to(win.home[0], win.home[1], 0.0) if not win.maxed else None
        self.focus(win)
        return win

    def close_window(self, win):
        win.closing = True
        win.alpha.t = 0.0
        win.sc.t = 0.88
        win.pos.a[2].t -= 200.0
        if self.focused is win:
            self.focused = None
        self._refocus()

    def minimize_window(self, win):
        win.minimized = True
        win.alpha.t = 0.0
        win.sc.t = 0.18
        ic = self.dock_icon("window:" + win.app_id)
        win.pos.to(ic.pos.x if ic else 0.0, -self.H / 2.0 + 90.0, 60.0)
        if self.focused is win:
            self.focused = None
        self._refocus()

    def toggle_max(self, win):
        win.maxed = not win.maxed
        if win.maxed:
            win.sc.t = min((self.W - 70) / win.w, (self.H - 190) / win.h, 1.3)
            win.pos.to(0.0, 12.0, 60.0)
        else:
            win.sc.t = 1.0
            win.pos.to(win.home[0], win.home[1], 0.0)

    def _live(self):
        return [w for w in self.windows.values() if not w.closing and not w.minimized]

    def _refocus(self):
        live = self._live()
        if live:
            self.focus(live[-1])
        else:
            self._restack()

    def focus(self, win):
        if win is None:
            return
        self.windows.pop(win.app_id, None)
        self.windows[win.app_id] = win           # en sona = en uste
        self.focused = win
        self._restack()

    def _restack(self):
        live = self._live()
        for rank, w in enumerate(reversed(live)):
            w.focused = (w is self.focused)
            if w.closing or w.maxed:
                continue
            w.pos.a[2].t = 40.0 if w.focused else -60.0 - 55.0 * (rank - 1)
            w.glow.t = 0.55 if w.focused else 0.0
            w.dirty = True
        self.topbar.title = self.focused.title if self.focused else ""
        self.topbar.dirty = True

    def window_of(self, obj):
        while obj is not None and not isinstance(obj, Window):
            obj = obj.parent
        return obj

    # ------------------------------------------------------------------ dock
    def build_dock(self):
        grads = {"store": (T.BLUE, T.PURPLE), "monitor": (T.GOOD, T.BLUE), "system": (T.hexc("94A3B8"), T.hexc("475569")),
                 "term": (T.hexc("334155"), T.hexc("0F172A"))}
        items = [
            ("window:store", "Nexus Store", "\u2726", grads["store"], lambda: self.toggle_window("store")),
            ("window:monitor", "System Monitor", "\u2630", grads["monitor"],
             lambda: self.toggle_window("monitor")),
            ("term", "Terminal", "\u276f", grads["term"], lambda: self.bridge.launch("xterm")),
            ("window:system", "System", "\u2699", grads["system"], lambda: self.toggle_window("system")),
        ]
        for a in self.apps:
            if a.exec and self.bridge.is_installed(a.pkg):
                g = T.CAT_COLORS.get(a.category, T.DEFAULT_GRAD)
                items.append(("app:" + a.id, a.name, a.glyph, g, (lambda ex=a.exec: self.bridge.launch(ex))))
        self.dock.set_items(items)
        self.dock.attach()

    def dock_icon(self, key):
        for i in self.dock.icons:
            if i.key == key:
                return i
        return None

    def toggle_window(self, app_id):
        win = self.windows.get(app_id)
        if win and not win.closing and not win.minimized and win is self.focused:
            self.minimize_window(win)
        else:
            self.open_window(app_id)

    # ------------------------------------------------------------------ yardimcilar
    def online(self):
        now = time.monotonic()
        if now - self._net_t > 5.0:
            self._net_t = now
            ok = False
            try:
                for n in os.listdir("/sys/class/net"):
                    if n != "lo":
                        with open("/sys/class/net/%s/operstate" % n) as f:
                            ok = ok or f.read().strip() == "up"
            except OSError:
                ok = True
            if ok != self._net_ok:
                self._net_ok, self.topbar.dirty = ok, True
        return self._net_ok

    def system_action(self, key):
        if key == "restart_shell":
            self.exit_requested = True
        else:
            sysinfo.power(key)

    # ------------------------------------------------------------------ girdi
    def _pick(self, mx, my):
        return self.scene.pick(mx, my, self.objs)

    def on_mouse_move(self, mx, my):
        self.mouse = (mx, my)
        if self.drag:
            win, ox, oy, z = self.drag
            p = self.scene.world_on_plane(mx, my, z)
            if p:
                x = max(-self.W / 2 + 120, min(self.W / 2 - 120, p[0] + ox))
                y = max(-self.H / 2 + 150, min(self.H / 2 - 50, p[1] + oy))
                win.pos.to(x, y, z)
                win.home = (x, y)
            return
        res = self._pick(mx, my)
        obj = res[0] if res else None
        if obj is not self.hover:
            if self.hover:
                self.hover.mouse_leave()
            self.hover = obj
        if res:
            res[0].mouse_move(res[1], res[2])

    def on_mouse_down(self, mx, my):
        self.mouse = (mx, my)
        res = self._pick(mx, my)
        if not res:
            self.pressed = None
            return
        obj, px, py, _ = res
        self.pressed = obj
        obj.down = True
        obj.dirty = True
        win = self.window_of(obj)
        if win and not win.minimized and obj is not self.topbar:
            self.focus(win)
            if win is obj and obj.is_titlebar(px, py) and not obj.maxed:
                z = obj.pos.a[2].t
                p = self.scene.world_on_plane(mx, my, z)
                if p:
                    self.drag = (obj, obj.pos.a[0].t - p[0], obj.pos.a[1].t - p[1], z)
                    obj.glow.t = 0.9

    def on_mouse_up(self, mx, my):
        self.mouse = (mx, my)
        pressed, self.pressed = self.pressed, None
        if pressed:
            pressed.down = False
            pressed.dirty = True
        if self.drag:
            win = self.drag[0]
            self.drag = None
            win.glow.t = 0.55 if win is self.focused else 0.0
            return
        res = self._pick(mx, my)
        if res and pressed is res[0]:
            obj, px, py, _ = res
            if isinstance(obj, DockIcon):
                self.dock.click(obj)
            else:
                obj.click(px, py)

    def on_wheel(self, dy):
        win = self.window_of(self.hover) or self.focused
        if win:
            win.on_wheel(dy)

    def on_key(self, ch):
        if self.focused:
            self.focused.on_key(ch)

    # ------------------------------------------------------------------ kare
    def update(self, dt):
        self.objs = self.scene.update(dt, self.mouse)
        self.dock.update(self.mouse)
        for key, win in list(self.windows.items()):
            if win.closing and win.alpha.x < 0.03:
                self.scene.remove(win)
                del self.windows[key]
            elif win.minimized and win.alpha.x < 0.03:
                win.visible = False
        for ic in self.dock.icons:
            w = self.windows.get(ic.key.split(":", 1)[1]) if ic.key.startswith("window:") else None
            ic.set_running(bool(w and not w.closing))
        sig = frozenset(self.bridge.installed)
        if sig != self._inst_sig:
            first, self._inst_sig = self._inst_sig is None, sig
            if not first:
                self.build_dock()
        for o in self.objs + self.scene.overlay:
            if o.dirty and o.alpha.x > 0.02:
                o.redraw()

    def render(self, t):
        g = self.gfx
        floor_y = -self.H / 2.0 - 40.0
        g.background(self.scene, t, A1, A2, floor_y)
        order = self.scene.draw_order(self.objs)
        g.shadows(self.scene, order, floor_y)
        for o in order:
            g.draw(self.scene, o)
        for o in self.scene.overlay:
            g.draw(self.scene, o, overlay=True)


# ===================================================================== calistirici
def _open_display(pygame, windowed, soft):
    """GL 3.3 core baglami ac. soft=True ise Mesa llvmpipe (yazilim) zorlanir."""
    if soft:
        os.environ["LIBGL_ALWAYS_SOFTWARE"] = "1"
        os.environ["GALLIUM_DRIVER"] = "llvmpipe"
    pygame.display.quit()
    pygame.display.init()
    pygame.display.set_caption("Nexus Shell")
    pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MAJOR_VERSION, 3)
    pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MINOR_VERSION, 3)
    pygame.display.gl_set_attribute(pygame.GL_CONTEXT_PROFILE_MASK, pygame.GL_CONTEXT_PROFILE_CORE)
    flags = pygame.OPENGL | pygame.DOUBLEBUF
    if windowed:
        pygame.display.set_mode((1440, 860), flags, vsync=1)
    else:
        pygame.display.set_mode((0, 0), flags | pygame.FULLSCREEN, vsync=1)
    return pygame.display.get_window_size()


def run():
    import pygame
    from .gl import Gfx

    windowed = os.environ.get("NEXUS_WINDOWED") == "1"
    quality = os.environ.get("NEXUS_QUALITY", "high")
    pygame.init()
    gfx = None
    for soft in (os.environ.get("NEXUS_SOFTWARE_GL") == "1", True):   # once donanim, olmazsa yazilim GL
        try:
            W, H = _open_display(pygame, windowed, soft)
            gfx = Gfx(W, H, quality)
            break
        except (pygame.error, RuntimeError) as e:
            print("[nexus-shell] GL baslatilamadi (%s): %s" % ("yazilim" if soft else "donanim", e), file=sys.stderr)
    if gfx is None:
        return 1
    print("[nexus-shell] %dx%d  GL: %s" % (W, H, gfx.renderer), file=sys.stderr)
    shell = Shell(W, H, gfx)
    clock = pygame.time.Clock()
    t0 = time.time()
    running = True
    while running and not shell.exit_requested:
        dt = min(clock.tick(120) / 1000.0, 0.05)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = running and not windowed
            elif e.type == pygame.MOUSEMOTION:
                shell.on_mouse_move(*e.pos)
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                shell.on_mouse_down(*e.pos)
            elif e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                shell.on_mouse_up(*e.pos)
            elif e.type == pygame.MOUSEWHEEL:
                shell.on_wheel(e.y)
            elif e.type == pygame.KEYDOWN:
                mods = pygame.key.get_mods()
                if e.key == pygame.K_q and mods & pygame.KMOD_CTRL and mods & pygame.KMOD_ALT:
                    running = False                              # gelistirici kacis yolu: Ctrl+Alt+Q
                elif e.key == pygame.K_BACKSPACE:
                    shell.on_key("BACKSPACE")
                elif e.key == pygame.K_RETURN:
                    shell.on_key("ENTER")
                elif e.key == pygame.K_ESCAPE:
                    shell.on_key("ESC")
                elif e.unicode:
                    shell.on_key(e.unicode)
        shell.update(dt)
        shell.render(time.time() - t0)
        pygame.display.flip()
    pygame.quit()
    return 0


if __name__ == "__main__":
    sys.exit(run())
