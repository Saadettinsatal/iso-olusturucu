"""dock.py -- 3D yuzen dock (simgeler yaklasir, yatar, parlar) ve ust cubuk."""
import math
import time

from . import mathx as M
from . import sysinfo, theme as T
from .objects import Obj3D
from .raster import text_width
from .spring import Spring, Spring3, BOUNCY

ICON = 88                      # simge yuzeyi (piksel)
BASE_SC = 0.82                 # dinlenme olcegi
SLOT = 74.0                    # simge araligi (dunya birimi)
DOCK_Z = 96.0


class DockIcon(Obj3D):
    def __init__(self, key, label, glyph, grad, action):
        super().__init__(ICON, ICON, radius=22, kind="icon")
        self.key, self.label, self.glyph, self.grad, self.action = key, label, glyph, grad, action
        self.pos = Spring3(0, 0, 0, **BOUNCY)
        self.sc = Spring(BASE_SC, k=300.0, c=17.0)
        self.tilt_deg = 14.0
        self.tint = (0.10, 0.13, 0.26, 0.5)
        self.glow_col = grad[0][:3]
        self.bevel, self.rim = 12.0, 1.0
        self.running = False
        self.shadow = False
        self.bounce = 0.0

    def draw(self, c, ui):
        c.rrect(8, 4, 72, 72, 20, grad=self.grad)
        c.rrect(8, 4, 72, 72, 20, border=(255, 255, 255, 90))
        c.rrect(10, 5, 68, 30, 18, grad=((255, 255, 255, 70), (255, 255, 255, 0)))
        c.text(44, 4 + (72 - 40 * 1.3) / 2 + 1, self.glyph, 40, (255, 255, 255, 250), "sym", "c")
        if self.running:
            c.circle(44, 83, 3, fill=T.alpha(T.BLUE, 255))

    def set_running(self, v):
        if v != self.running:
            self.running, self.dirty = v, True


class Tooltip(Obj3D):
    def __init__(self):
        super().__init__(160, 34, radius=17, kind="tip")
        self.text = ""
        self.no_pick, self.shadow = True, False
        self.alpha.set(0.0)
        self.tint = (0.04, 0.06, 0.12, 0.85)
        self.bevel, self.rim = 8.0, 0.5

    def set_text(self, text):
        if text != self.text:
            self.text = text
            self.w = int(text_width(text, 14, "bold")) + 32
            from .raster import Canvas
            self.canvas = Canvas(self.w, self.h)
            self.tex = None
            self.dirty = True

    def draw(self, c, ui):
        c.text(self.w / 2, 8, self.text, 14, T.TEXT, "bold", "c")


class DockBar(Obj3D):
    """Icerigi olmayan buzlu cam levha."""

    def __init__(self):
        super().__init__(300, 92, radius=34, kind="dock")
        self.no_tex = self.no_pick = True
        self.tint = (0.05, 0.08, 0.17, 0.42)
        self.bevel, self.rim = 20.0, 0.9
        self.glow_col = T.PURPLE[:3]
        self.glow.set(0.25)
        self.glow.t = 0.25


class Dock:
    """Simgeleri yerlestirir; fare isini dock duzlemiyle keserek buyutme hesaplar."""

    def __init__(self, scene, shell):
        self.scene, self.shell = scene, shell
        self.icons = []
        self.bar = DockBar()
        self.tip = Tooltip()
        self.bar.kids = []
        scene.add(self.bar)
        scene.add(self.tip)
        self.hovered = None
        self.layout_x = {}

    # ----------------------------------------------------------- icerik
    def set_items(self, items):
        """items: [(key, label, glyph, grad, action)] -- degisenleri koruyarak guncelle."""
        old = {i.key: i for i in self.icons}
        new = []
        for key, label, glyph, grad, action in items:
            ic = old.get(key) or DockIcon(key, label, glyph, grad, action)
            ic.action = action
            if key not in old:
                ic.sc.set(0.1)
                ic.sc.t = BASE_SC
                ic.alpha.set(0.0)
                ic.alpha.t = 1.0
            new.append(ic)
        for ic in self.icons:
            if ic not in new:
                self.scene.remove(ic)
        for ic in new:
            self.scene.add(ic)
        self.icons = new
        self.bar.kids = []

    def attach(self):
        """Dock levhasini ilk sirada tut (simgelerin arkasinda cizilsin)."""
        for o in (self.bar,):
            if o in self.scene.roots:
                self.scene.roots.remove(o)
            self.scene.roots.insert(0, o)

    # ----------------------------------------------------------- guncelleme
    def update(self, mouse):
        H = self.scene.cam.h
        base_y = -H / 2.0 + 76.0
        mx_world = None
        near = False
        if mouse:
            p = self.scene.world_on_plane(mouse[0], mouse[1], DOCK_Z)
            if p and abs(p[1] - base_y) < 95 and abs(p[0]) < (len(self.icons) * SLOT) / 2 + 160:
                mx_world, near = p[0], True
        # buyutme hedefleri (macOS tarzi gauss)
        scales = []
        for ic in self.icons:
            cx = self.layout_x.get(ic.key, 0.0)
            if near:
                d = abs(mx_world - cx)
                s = BASE_SC + 0.78 * math.exp(-(d * d) / (2 * 62.0 * 62.0))
            else:
                s = BASE_SC
            scales.append(s)
        # yerlesim: komsular itilir (olcege gore genislik)
        widths = [SLOT * (0.55 + 0.45 * ic.sc.x / BASE_SC) for ic in self.icons]
        total = sum(widths)
        x = -total / 2.0
        hov = None
        for ic, s, wd in zip(self.icons, scales, widths):
            cx = x + wd / 2.0
            self.layout_x[ic.key] = cx
            lift = (s - BASE_SC)
            ic.pos.to(cx, base_y + lift * 42.0, DOCK_Z + lift * 80.0)
            ic.sc.t = s
            ic.glow.t = min(1.0, lift / 0.78) * 0.95
            ic.rot.to(0, 0, 0)
            x += wd
            if lift > 0.45 and (hov is None or s > hov[1]):
                hov = (ic, s)
        self.hovered = hov[0] if hov else None
        # levha
        self.bar.w = int(total + 56)
        self.bar.pos.to(0, base_y - 4, DOCK_Z - 34)
        self.bar.pos.set(0, base_y - 4, DOCK_Z - 34) if self.bar.pos.at_rest() else None
        # ipucu
        if self.hovered:
            ic = self.hovered
            self.tip.set_text(ic.label)
            self.tip.pos.to(ic.pos.x, ic.pos.y + 74 * ic.sc.x / BASE_SC + 12, ic.pos.z + 40)
            if self.tip.alpha.t < 0.5:
                self.tip.pos.set(ic.pos.x, ic.pos.y + 74 * ic.sc.x / BASE_SC + 12, ic.pos.z + 40)
            self.tip.alpha.t = 1.0
        else:
            self.tip.alpha.t = 0.0

    def click(self, ic):
        ic.pos.a[1].v += 520.0                       # ziplama
        ic.sc.v += 3.0
        if ic.action:
            ic.action()


class TopBar(Obj3D):
    """Ekran uzayinda (3D degil) ince cam cubuk: logo, etkin pencere, ag, saat."""

    def __init__(self, shell, w):
        super().__init__(w - 24, 40, radius=20, kind="bar")
        self.shell = shell
        self.screen_space = True
        self.no_pick = False
        self.tint = (0.04, 0.07, 0.15, 0.5)
        self.bevel, self.rim = 10.0, 0.4
        self.shadow = False
        self.title = ""
        self._sec = -1

    def tick(self, dt):
        sec = int(time.time() // 30)
        if sec != self._sec:
            self._sec = sec
            return True
        return False

    def draw(self, c, ui):
        from . import VERSION
        c.text(18, 9, "\u25c8", 20, T.BLUE, "sym")
        c.text(44, 10, "NEXUS", 16, T.TEXT, "bold")
        c.rrect(110, 10, 44, 20, 10, fill=T.alpha(T.PURPLE, 70), border=T.alpha(T.PURPLE, 140))
        c.text(132, 12, "v%s" % VERSION, 11, T.TEXT, "bold", "c")
        if self.title:
            c.text(self.w / 2, 11, self.title, 14, T.MUTED, "ui", "c")
        online = self.shell.online()
        c.text(self.w - 150, 11, "\u25cf", 13, T.GOOD if online else T.WARN, "sym", "r")
        c.text(self.w - 143, 11, "Online" if online else "Offline", 13, T.MUTED, "ui")
        c.text(self.w - 18, 10, time.strftime("%H:%M"), 16, T.TEXT, "bold", "r")
