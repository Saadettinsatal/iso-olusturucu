#!/usr/bin/env python3
"""preview.py -- GPU/GL olmadan Nexus Shell'in yazilim onizlemesi (PNG).

Gercek kamera matrisini kullanir; her 3D nesnenin yuzeyini perspektif donusumuyle
ekrana oturtur. Cam bulaniklik/isik efektleri YOKTUR (onlar GL shader'inda); amac
yerlesimi, perspektifi ve icerigi GPU'suz gormektir.

  python3 tools/preview.py out.png [--hover-card] [--detail] [--cat Games]
"""
import math
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.environ.setdefault("NEXUS_SIM", "1")

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

from nexus import mathx as M, theme as T
from nexus.bridge import StoreBridge
from nexus.raster import _mask
from nexus.shell import Shell


def homography(dst, src):
    """dst (4 nokta, cikti) -> src (4 nokta, kaynak) PIL PERSPECTIVE katsayilari."""
    A, b = [], []
    for (x, y), (u, v) in zip(dst, src):
        A.append([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.append(u)
        A.append([0, 0, 0, x, y, 1, -v * x, -v * y]); b.append(v)
    return np.linalg.solve(np.array(A, float), np.array(b, float))


def background(W, H, shell, floor_y):
    img = Image.new("RGB", (W, H))
    px = ImageDraw.Draw(img)
    for y in range(H):                                     # gokyuzu: ufukta mor, yukarida lacivert
        t = y / H
        c = (int(15 + 40 * (1 - t) ** 3), int(23 + 6 * (1 - t) ** 3), int(42 + 40 * (1 - t) ** 3))
        px.line([(0, y), (W, y)], fill=c)
    vp = shell.scene.vp
    for i in range(-30, 31):                               # neon zemin izgarasi (gercek perspektif)
        for a, b in (((i * 150, floor_y, 300), (i * 150, floor_y, -5000)), ((-4500, floor_y, -i * 150 + 300), (4500, floor_y, -i * 150 + 300))):
            p, q = M.project(vp, a, W, H), M.project(vp, b, W, H)
            if p and q:
                px.line([p[:2], q[:2]], fill=(40 + 20 * (i % 2), 90, 160), width=1)
    img = img.convert("RGBA")
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    for cx, cy, r, col in ((W * 0.15, H * 0.2, 360, T.BLUE), (W * 0.85, H * 0.75, 420, T.PURPLE)):
        g.ellipse((cx - r, cy - r, cx + r, cy + r), fill=col[:3] + (55,))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(120)))
    return img


def body_of(obj):
    """Cam govdesi yaklasigi: yari saydam lacivert + ince kenar."""
    w, h = obj.w, obj.h
    t = obj.tint
    a = 252 if obj.kind in ("window", "card", "icon") else 150
    base = Image.new("RGBA", (w, h), (int(t[0] * 255 * 1.6 + 8), int(t[1] * 255 * 1.6 + 12), int(t[2] * 255 * 1.4 + 20), a))
    m = _mask(w, h, int(obj.radius))
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(base, (0, 0), m)
    out.alpha_composite(obj.canvas.img)
    ring = Image.new("L", (w, h), 0)
    ImageDraw.Draw(ring).rounded_rectangle((0, 0, w - 1, h - 1), radius=obj.radius, outline=255, width=2)
    col = obj.glow_col + (255,)
    edge = Image.new("RGBA", (w, h), col[:3] + (0,))
    edge.putalpha(ring.point(lambda v: int(v * (0.28 + 0.6 * max(0, obj.glow.x)))))
    out.alpha_composite(edge)
    mm = Image.new("L", (w, h), 0)
    mm.paste(m, (0, 0))
    out.putalpha(Image.fromarray(np.minimum(np.array(out.getchannel("A")), np.array(m))))
    return out


def draw_obj(frame, shell, obj, overlay=False):
    W, H = frame.size
    src = body_of(obj)
    if overlay:
        sc = obj.sc.x
        cx, cy = obj.pos.x, obj.pos.y
        quad = [(cx - obj.w / 2 * sc, cy - obj.h / 2 * sc), (cx + obj.w / 2 * sc, cy - obj.h / 2 * sc),
                (cx + obj.w / 2 * sc, cy + obj.h / 2 * sc), (cx - obj.w / 2 * sc, cy + obj.h / 2 * sc)]
    else:
        hw, hh = obj.w / 2, obj.h / 2
        quad = []
        for lx, ly in ((-hw, hh), (hw, hh), (hw, -hh), (-hw, -hh)):
            p = M.project(shell.scene.vp, M.transform(obj._model, (lx, ly, 0))[:3], W, H)
            if not p:
                return
            quad.append(p[:2])
    xs, ys = [p[0] for p in quad], [p[1] for p in quad]
    pad = 70 if obj.glow.x > 0.05 else 4
    x0, y0, x1, y1 = int(min(xs)) - pad, int(min(ys)) - pad, int(max(xs)) + pad, int(max(ys)) + pad
    bw, bh = x1 - x0, y1 - y0
    if bw < 2 or bh < 2 or bw > 4000:
        return
    dst = [(x - x0, y - y0) for x, y in quad]
    co = homography(dst, [(0, 0), (obj.w, 0), (obj.w, obj.h), (0, obj.h)])
    # golge (zemine yumusak) ve parilti
    layer = src.transform((bw, bh), Image.PERSPECTIVE, tuple(co), resample=Image.BICUBIC)
    a = obj.alpha.x
    if a < 0.999:
        layer.putalpha(layer.getchannel("A").point(lambda v: int(v * max(0, a))))
    if obj.dim.x < 0.99:
        dk = Image.new("RGBA", layer.size, (6, 10, 22, int(255 * (1 - obj.dim.x))))
        dk.putalpha(Image.fromarray(np.minimum(np.array(dk.getchannel("A")), np.array(layer.getchannel("A")))))
        layer.alpha_composite(dk)
    if obj.glow.x > 0.05:
        gl = Image.new("RGBA", layer.size, obj.glow_col + (0,))
        gl.putalpha(layer.getchannel("A").filter(ImageFilter.GaussianBlur(18)).point(lambda v: int(v * 0.7 * min(1, obj.glow.x))))
        frame.alpha_composite(gl, (x0, y0)) if x0 >= 0 and y0 >= 0 else frame.paste(gl, (x0, y0), gl)
    frame.alpha_composite(layer.crop((max(0, -x0), max(0, -y0), min(bw, W - x0), min(bh, H - y0))), (max(0, x0), max(0, y0)))


def shadow(frame, shell, obj, floor_y):
    W, H = frame.size
    m = obj._model
    cx, cy, cz = m[3], m[7], m[11]
    s = math.sqrt(m[0] ** 2 + m[4] ** 2 + m[8] ** 2)
    hw, dp = obj.w * s * 0.46, obj.w * s * 0.13
    pts = [M.project(shell.scene.vp, (cx + dx, floor_y, cz + dz), W, H) for dx, dz in ((-hw, -dp), (hw, -dp), (hw, dp), (-hw, dp))]
    if not all(pts):
        return
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).polygon([p[:2] for p in pts], fill=(0, 0, 0, int(150 * obj.alpha.x)))
    frame.alpha_composite(sh.filter(ImageFilter.GaussianBlur(26)))


def render(shell, W, H):
    floor_y = -H / 2 - 40
    frame = background(W, H, shell, floor_y)
    order = shell.scene.draw_order(shell.objs)
    for o in order:
        if o.shadow and o.kind in ("window", "card") and o.alpha.x > 0.05:
            shadow(frame, shell, o, floor_y)
    for o in order:
        draw_obj(frame, shell, o)
    for o in shell.scene.overlay:
        draw_obj(frame, shell, o, overlay=True)
    return frame


def main():
    args = sys.argv[1:]
    out = args[0] if args and not args[0].startswith("--") else "/tmp/nexus_preview.png"
    W, H = 1600, 900
    sh = Shell(W, H, gfx=None, bridge=StoreBridge(sim=True))
    step = lambda sec: [sh.update(1 / 60) for _ in range(int(sec * 60))]
    step(2.5)
    if "--cat" in args:
        name = args[args.index("--cat") + 1]
        from nexus.catalog import CATEGORIES
        sh.windows["store"].cat = CATEGORIES.index(name)
        sh.windows["store"].layout()
        step(2)
    sh.open_window("monitor"); sh.open_window("system"); sh.open_window("store")
    step(2.5)
    store = sh.windows["store"]
    if "--hover-card" in args:
        c = [k for k in store.cards if k.visible][1]
        lx, ly = 0, 30
        p = M.project(sh.scene.vp, M.transform(c._model, (lx - 60, ly, 0))[:3], W, H)
        sh.on_mouse_move(p[0], p[1]); step(0.8)
    elif "--dock" in args:
        ic = sh.dock.icons[0]
        p = M.project(sh.scene.vp, M.transform(ic._model, (0, 0, 0))[:3], W, H)
        sh.on_mouse_move(p[0] + 30, p[1]); step(1.0)
    if "--detail" in args:
        store.show_detail(store.cards[0].app); step(1.2)
    render(sh, W, H).convert("RGB").save(out)
    print("yazildi:", out)


if __name__ == "__main__":
    main()
